# ISBE 1915 — multilingual editorial Markdown workspace

English files under `en/articles/` are **read-only derived views** of the corrected historical TEI. Each `en/maps/` JSON sidecar retains the COMPLETE source element tree, attributes, text and tails with stable preorder node ordinals. Markdown is not a replacement for TEI, and Markdown edits alone cannot be reimported safely.

Always make translations through source-locked exact-unit patches and validate reconstruction against the immutable English TEI. The original SWORD keys, xml:id values, Hebrew/Greek, references, citation targets and notes must never be silently altered.

Optional `fr/unreviewed/` files are generated reading proofs from existing French patches: **not independently editorially approved, not a complete French edition, not for publication**.

See MANIFEST.json for exact SHA-256, source-index order, article checksums and completeness counts.
