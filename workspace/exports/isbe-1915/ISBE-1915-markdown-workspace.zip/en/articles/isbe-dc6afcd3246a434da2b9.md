# ABLE

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 5eadb67cb42a59e698b778082d468ec3d70060f5469a26dd8c7a7fce42be295b -->

a'-b'-l: The Greek dunamai, "to have power," may refer either to inherent strength, or to the absence of in external obstacles, or to what may be allowable or permitted. The Greek ischuo, as in Lu 13:24; Joh 21:6, refers always to the first of the above meanings. The use of the word as an adjective the King James Version of 2Co 3:6, is misleading, and has been properly changed in the Revised Version (British and American) into "sufficient as ministers," i.e. "hath fitted us to be ministers."
