# ADORAIM

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 5f4aa476a31de23cb5db1615025fe8fb7cccbe5f8b718239114969655b5d3aa2 -->

ad-o-ra'-im ('adhorayim, "a pair of knolls," perhaps): One of several cities in Judah that were fortified by Rehoboam (2Ch 11:9). The name appears in Josephus and in 1 Macc as Adora or Dora or Dor. Its location is indicated in general by that of the other cities which the record in Chronicles groups with it. Common consent identifies it with Dura, about five miles West by South of Hebron.
