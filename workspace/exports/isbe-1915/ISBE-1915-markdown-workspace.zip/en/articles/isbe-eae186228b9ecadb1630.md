# ADONIJAH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 40b5decc04dc960fafc3eedda9a83189c2f93eef6ca327b3d5f5f6f13ea81851 -->

ad-o-ni'-ja ('adhoniyahu or 'adhoniyah, "my lord is Yahweh"):

(1) The son of David and Haggith, the forth of David's sons, born in Hebron after David became king of Judah, principally known for his attempt to become king instead of Solomon (2Sa 3:4; 1Ch 3:2; 1Ki 1,2). The record gives no details concerning Chileab, the son of David and Abigail. Leaving him out, Adonijah was the oldest living son of David, after the death of Amnon and Absalom.

In treating the record it has been needlessly obscured by neglecting or distorting the time data. It says that the rebellion of Absalom broke out "at an end of forty years" (2Sa 15:7). The natural meaning is not forty years after the last-mentioned preceding date, but at the close of the fortieth calendar year of the reign of David. Since David reigned 40 1/2 years (2Sa 5:4,5), the close of his fortieth calendar year was the beginning of has last year. That the date intended was at the beginning of a vernal year is confirmed by the references to the season (2Sa 17:19,28). Instead of giving this number Josephus says that 4 years had elapsed since the last preceding date, which is very likely correct.

Many considerations show that the outbreak cannot have occurred much earlier than the fortieth year of David; for Amnon and Absalom were born after David's reign began, and were men with establishments of their own before Amnon's offense against Tamar, and after that the record, if we accept the numeral of Josephus, accounts for 2 plus 3 plus 2 plus 4, that is, for 11 years (2Sa 13:23,38; 14:28; Ant, VII, ix, 1). In the year following David's fortieth year there was ample room for the rebellions of Absalom and of Sheba, the illness of David, the attempt of Adonijah, and the beginning of the reign of Solomon. All things confirm the number forty as giving the date of the outbreak. The common assumption that the forty is to be reduced to four, on the basis of the number in Josephus, is contrary to the evidence.

On this view of the chronology all the events fall into line. David's idea of making Solomon king was connected with his temple-building idea. This is implied in Kings, and presented somewhat in full in Chronicles. The preparations described in Chronicles (1Ch 22-29) seem to have culminated in David's fortieth year (1Ch 26:31). David's policy was not altogether popular with the nation. His assembly (1Ch 28:1) is mostly made up of sarim and other appointed officials, the hereditary Israelite "princes" and "elders" being conspicuous by their absence. The outbreak under Absalom was mainly a matter of skillful manipulation; the hearts of the people were really with David. And yet the party of Absalom was distinctly a legitimist party. It believed in the succession of the eldest son, and it objected to many things in the temple-building policy. Joab and Abiathar and others sympathized with this party, but they remained with David out of personal loyalty to him.

The Absalom campaign began early in the calendar year. There is no reason to think that it lasted more than a few weeks. Later in the year a few weeks are enough time to allow for the campaign against Sheba. Joab must have been more or less alienated from David by David's appointment of Amasa to supersede him. Then came David's serious illness. Abishag was brought in, not to "attend upon David during has declining years," but to put her vitality at has disposal during a few weeks. Joab and Abiathar did not believe that David would ever do business again. Their personal loyalty to him no longer restrained them from following their own ideas, even though these were contrary to his wishes.

The narrative does not represent that Nathan and Bathsheba influenced David to interfere in behalf of Solomon; it represents that they succeeded in arousing him from has torpor, so that he carried out his own wishes and intentions. Perhaps resting in bed had done something for him. The treatment by Abishag had not been unsuccessful. And now a supreme appeal to his mind proved sufficient to arouse him. He became himself again, and acted with has usual vigor and wisdom.

Adonijah is described as a handsome and showy man, but his conduct does not give us a high opinion of his capabilities. He had no real command of the respect of the guests who shouted "Live King Adonijah." When they heard that Solomon had been crowned, they "were afraid, and rose up, and went every man his way." Adonijah made has submission, but afterward attempted to engage in intrigues, and was put to death.

(2) One of the Levites sent out by Jehoshaphat, in his third year, with the Book of the Law, to give instruction in Judah (2Ch 17:8).

(3) One of the names given, under the heading "the chiefs of the people," of those who sealed the covenant along with Nehemiah (Ne 10:16).

Willis J. Beecher
