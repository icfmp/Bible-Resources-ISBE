# ADAM, BOOKS OF

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: b2f70a0f52ac3f29fad4f56f8d35a041acfeaaac986ca18f726e8f5860725aa7 -->

Books pretending to give the life and deeds of Adam and other Old Testament worthies existed in abundance among the Jews and the early Christians. The Talmud speaks of a Book of Adam, which is now lost, but which probably furnished some of the material which appears in early Christian writings. The Vita Adami was translated from the Ethiopic by Dillmann (1853), and into English by Malan (The Book of Adam and Eve, London, 1882). The Testament of Adam is a portion of the Vita Adami (published by Renan in 1853) and so probably is the Diatheke ton Protoplaston (Fabricius, II, 83). See APOCALYPTIC LITERATURE; APOCRYPHA.

M. O. Evans
