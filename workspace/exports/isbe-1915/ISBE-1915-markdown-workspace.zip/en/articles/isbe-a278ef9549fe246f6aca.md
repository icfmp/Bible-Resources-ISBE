# ACELDAMA

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 477e278a279728354d977f75ef4185cbe3345a37ab1c102b9180ed627dfc033a -->

a-sel'-da-ma. See AKELDAMA.
