# AL-TASHHETH; AL-TASCHITH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: f996db93997933f604937619a353a458b6b1cbfc745fb23c04899e9afa4a9ad1 -->

al-tash'-heth, al-tas'-kith. See PSALMS; SONG.
