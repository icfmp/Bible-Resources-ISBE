# AGES, ROCK OF

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 6d4610e08dd225c0d0c278b74ff3bd0ae779df00ca4867fd95f0f46531af82c1 -->

Applied to Yahweh as an encouragement for trust (Isa 26:4 the Revised Version, margin; the King James Version "everlasting strength").
