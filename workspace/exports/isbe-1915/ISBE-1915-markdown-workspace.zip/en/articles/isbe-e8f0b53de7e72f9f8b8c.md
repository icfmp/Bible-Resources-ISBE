# ACCOZ

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 49aa6dcf1c8b1a5b7d5f42df9f3802cc57e983357d4db807e0cb4624f22a2a81 -->

ak'-oz (Akbos; the Revised Version (British and American) AKKOS, which see): 1 Esdras 5:38, head of one of the priestly families, which returned from the Exile, but was unable to prove its descent, when the register was searched. See also Ezr 2:61.
