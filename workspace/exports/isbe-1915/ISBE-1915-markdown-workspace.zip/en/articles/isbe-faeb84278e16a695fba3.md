# AFTERNOON

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 1a902ff5f03e00eeace4dc2838f995b3ffc52c59da27f1f1ba9a5e255ea92065 -->

af-ter-noon' (neToth ha-yom, "the declining of the day"; Jud 19:8 the King James Version): The expression kechom ha-yom, "in the heat of the day" (Ge 18:1) refers to the early afternoon when the sun is a little past its zenith, its rays still being very strong. The phrase le-ruach ha-yom, "in the cool of the day" (Ge 3:8) is in contrast to the last phrase and points to the late afternoon; in the Orient a cooling breeze arises at this period of the day, and it is then that much of the day's business is transacted.

See DAY.
