# ALLIED

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: d28baacb23499068c557ecc649444524ad4b64e12d8684694c0ab799d6a64001 -->

a-lid' (qarobh, "near," as in Ge 45:10; Ex 13:17, etc.): Ne 13:4 refers either to family ties, as in Ru 2:20, or to intimate association.
