# ADO

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: ba52b6ca1970d7ecc1a7a3cf9a71c22864b95ca4801e99cc20b6630556570a21 -->

a-doo': Found only in Mr 5:39 King James Version: "Why make ye this ado and weep?" Here "make ado" is used to translate the Greek verb thorubeomai (compare Mt 9:23 the King James Version, where it is likewise rendered "making a noise"). "Ado" as a substantive is Old English for "trouble" or "fuss," used only in the sing.; and in the early English versions it combined well with the verb "make," as here, to translate the Greek word rendered elsewhere "causing an uproar," or "tumult," "making a noise," etc. (see Ac 17:5; 20:10). Compare Shakespeare, Romeo and Juliet, III, 4, "We'll keep no great ado;--a friend or two."

George B. Eager
