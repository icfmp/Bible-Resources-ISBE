# ABIA; ABIAH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 9fcb9d2d5cad52fefd66c9d2de96d0f86338b4ea7e0ce9b736fb6b02e35575ad -->

a-bi'-a, a-bi'-ah: Variants for ABIJAH; which see.
