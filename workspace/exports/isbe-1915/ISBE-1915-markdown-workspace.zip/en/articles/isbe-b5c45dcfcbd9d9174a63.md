# ACHSAH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 00067ff7775e0e40856844a5cae10af54369a77c719266ad7151f6cef6fc56b5 -->

ak'-sa (`akhchah; in some copies `akhca' in 1Ch 2:49), ("anklet"): The daughter of Caleb whom he gave in marriage to his younger kinsman Othniel the son of Kenaz, as a reward for smiting Kiriath-sepher (Jos 15:16 ff; Jud 1:12 ff). Caleb, the narrative says, established Achsah in the South-country, and in addition, at her asking, gave her certain important springs of water--the "upper basins" and the "nether basins." Professor G. F. Moore identifies these with the groups of springs in Seit ed-Dilbeh (notes on Jud in Polychrome Bible).

Willis J. Beecher
