# AMBER

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: fcde77270d738f165b61c0ba39521ff6fd2046f52f879b7c57842acd5559fc03 -->

am'-ber. See STONES, PRECIOUS.
