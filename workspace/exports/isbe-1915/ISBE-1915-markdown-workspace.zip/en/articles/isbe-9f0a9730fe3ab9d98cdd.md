# AHUZZATH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: cc33b55b83f0f0d0cd3c4aebf7013d44c5ccd1dd53278b88e9319efa815b9872 -->

a-huz'-ath ('achuzzath, "possession"): A "friend" perhaps a minister, of Abimelech, king of Gerar. He together with Phicol, commander of the army, accompanied their sovereign to Beersheba to make a covenant with Isaac (Ge 26:26). The termination "-ath" reminds us of Philistine proper names, such as Gath, Goliath, etc. Compare Genubath (1Ki 11:20).
