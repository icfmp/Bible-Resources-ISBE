# ABIGAIL; ABIGAL

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: aaec2a89a2ed1b05f00f54e52c07e857825a0147ec809fc253d41ba26da69439 -->

ab'-i-gal, ab'-i-gal ('abhighayil, or 'abhighal, three times, or 'abhughayil, once, or 'abhighayil, once; "father," or "cause of joy"):

(1) The wife of Nabal, a rich shepherd of southern Judea, whose home was Maon (1Sa 25:2,3); shortly after Nabal's death she became the wife of David. Nabal grazed his flocks in or along the Southern Wilderness, where David and his men protected them from marauding tribes, so that not a sheep was lost. When Nabal was sheep-shearing and feasting at Carmel (in Judea), David sent messengers requesting provisions for himself and men. But Nabal, who was a churlish fellow, answered the messengers insultingly and sent them away empty-handed. David, angered by such mean ingratitude, gathered his 400 warriors and set out to destroy Nabal and all he had (1Sa 25:22). Meanwhile Abigail, a woman "of good understanding, and of a beautiful countenance" (1Sa 25:3), heard of the rebuff given the men of David by her husband; and fearing what vengeance David in his wrath might work, she gathered a considerable present of food (1Sa 25:18), and hastened to meet the approaching soldiers. Her beautiful and prudent words, as also her fair face, so won David that he desisted from his vengeful purpose and accepted her gift (1Sa 25:32-35). When Abigail told Nabal of his narrow escape, he was stricken with fear, and died ten days afterward. Shortly after this David took Abigail to be his wife, although about the same time, probably a little before, he had also taken Ahinoam (1Sa 25:43); and these two were with him in Gath (1Sa 27:3). After David became king in Hebron, Abigail bore him his second son, Chileab (2Sa 3:3) or Daniel, as he is called in 1Ch 3:1.

(2) Sister of David and mother of Amasa, at one time commander of David's army (1Ch 2:16,17; Abigal 2Sa 17:25). In the first passage she is called David's sister, along with Zeruiah; while in the second she is called the "daughter of Nahash." Several explanations of this connection with Nahash have been suggested, any one of which would be sufficient to remove contradiction:

(1) That Nahash was another name of Jesse, as in Isa 14:29, mish-shoresh nachash yetse' (Qimchi);

(2) That Nahash was the wife of Jesse and by him mother of Abigail, which is least probable;

(3) That Nahash, the father of Abigail and Zeruiah, having died, his widow became the wife of Jesse, and bore sons to him;

(4) That the text of 2Sa 17:25 has been corrupted, "daughter of Nahash" having crept into the text. At all events she was the sister of David by the same mother.

Edward Mack
