# ADADAH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: d4dbbb935c90b4200ea10a0d915e77cc356c349f1b3b4bb2ed4bdf360dd32aa4 -->

a-da'-da (`adh`adhah): A city in the southern part of Judah (Jos 15:22). The older copies of the Greek text have Arouel, but that is not a sufficient reason for identifying the name with the Aroer of 1Sa 30:28. Some scholars adopt the change of text, and identify the site with Ararah, about seven miles Southeast of Beer-sheba. Others identify it with Adadah, eight or nine miles Southeast of Arad.
