# AENON

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 95a13b8e74a2ff31d20f0a9fadd385ddb0da3605de431fa6261ab7d4e04f4eff -->

e'-non (Ainon): The place where John was baptizing "because there was much water there" (Joh 3:23). It was on the west side of the Jordan, the place where John baptized at the first being on the east (Joh 1:28; 3:26; 10:40). We may be sure it was not in Samaritan territory. Eusebius, Onomasticon locates it 8 Roman miles South of Scythopolis (Beisan), this stretch of land on the west of the Jordan being then, not under Samaria, but under Scythopolis. Its position is defined by nearness to Salim. Various identifications have been suggested, the most probable being the springs near Umm el-`Amdan, which exactly suit the position indicated by Eusebius, Onomasticon.omforter, Helper, Greek Paraclete. Beyond doubt however, "advocate ' is the correct translation in the passage in the epistle. The same Greek word also occurs in the Gospel of John (Joh 14:16,26; 15:26; 16:7) referring not to Christ but to the Holy Spirit, to whom Christ refers as "another comforter" whom He will send from the Father. In the Gospel various functions are ascribed to the Spirit in relation to believers and unbelievers. The word in the Gospel is inadequately translated "Comforter." The Spirit according to these passages, is more than Comforter and more than Advocate.

See discussion under SALIM.

W. Ewing
