# ABDIAS

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 0472aa7663ca3564f47a2b245698db1aa1fa07bd3ac9a5cdb092d811945eb992 -->

ab-di'-as (2 Esdras 1:39 = Obadiah): One of the Minor Prophets. Mentioned with Abraham, Isaac, Jacob and the Minor Prophets who shall be given as leaders to the "nation from the east" which is to overthrow Israel (compare OBADIAH).
