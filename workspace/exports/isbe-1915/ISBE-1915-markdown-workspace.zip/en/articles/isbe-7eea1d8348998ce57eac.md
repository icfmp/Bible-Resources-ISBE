# AHIMOTH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: e1e486f3406ed84ca5913afc7fd0bd1d4e5ecd9d8dff12d04a07d9a8104052e0 -->

a-hi'-moth ('achimoth, "brother of death," or, "my brother is death"): A descendant of Kohath the son of Levi (1Ch 6:25); ancestor of Elkanah the father of Samuel. The name Mahath holds a similar place in the list that follows (1Ch 6:35).
