# ABEL-MEHOLAH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 2bea3aca30d0f07b49819e98a0f4e8c05df06383090c8fdb7b8e1c2187222168 -->

a'-bel-me-ho'-lah ('abhel meholah, "meadow of dancing"): The residence of Elisha the prophet (1Ki 19:16). When Gideon and his 300 broke their pitchers in the camp of Midian, the Midianites in their first panic fled down the valley of Jezreel and the Jordan "toward Zererah" (Jud 7:22). Zererah (Zeredah) is Zarethan (2Ch 4:17; compare 1Ki 7:46), separated from Succoth by the clay ground where Solomon made castings for the temple. The wing of the Midianites whom Gideon pursued crossed the Jordan at Succoth (Jud 8:4 ff). This would indicate that Abel-meholah was thought of as a tract of country with a "border," West of the Jordan, some miles South of Beth-shean, in the territory either of Issachar or West Manasseh.

Abel-meholah is also mentioned in connection with the jurisdiction of Baana, one of Solomon's twelve commissary officers (1Ki 4:12) as below Jezreel, with Beth-shean and Zarethan in the same list. Jerome and Eusebius speak of Abel-meholah as a tract of country and a town in the Jordan valley, about ten Roman miles South of Beth-shean. At just that point the name seems to be perpetuated in that of the Wady Malib, and Abel-meholah is commonly located near where that Wady, or the neighboring Wady Helweh, comes down into the Jordan valley.

Presumably Adriel the Meholathite (1Sa 18:19; 2Sa 21:8) was a resident of Abel-meholah. Willis J. Beecher
