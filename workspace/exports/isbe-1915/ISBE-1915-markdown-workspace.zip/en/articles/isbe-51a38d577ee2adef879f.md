# AHIRAM

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 1c37d0b5f55ad2a9e16bce4c65d6ddad7bbd35b86191fbc9e57472d77c434b25 -->

a-hi'-ram ('achiram, "exalted brother," or "my brother is exalted"):

A son of Benjamin. Mentioned third of the five in Nu 26:38,39. In 1Ch 8:1 five sons are likewise mentioned, being explicitly numbered; the third name, Aharah ('achrach), is conjectured to be either a corruption of Ahiram or a different name for the same person. In 1Ch 7:6 ff is a fuller list of Benjamite names, but it is fragmentary and not clear. In it occurs Aher ('acher), which may be either Ahiram or Aharah with the end of the word lost. In Ge 46:21 ten sons of Benjamin are mentioned, some being there counted as sons who, in the other lists, are spoken of as more remote descendants. In this list Ehi ('echi) is perhaps Ahiram shortened. See AHARAH; AHER; EHI.

Willis J. Beecher
