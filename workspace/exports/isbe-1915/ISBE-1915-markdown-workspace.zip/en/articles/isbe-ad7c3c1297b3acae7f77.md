# AGONE

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 6f5f740785be963faf8d54d98fe9a00cb244c2a6e5df724835164d8018497b68 -->

a-gon': In the King James Version of 1Sa 30:13. Old past participle of "to go." the Revised Version (British and American) has "ago," namely, "three days ago," literally, "the third day."
