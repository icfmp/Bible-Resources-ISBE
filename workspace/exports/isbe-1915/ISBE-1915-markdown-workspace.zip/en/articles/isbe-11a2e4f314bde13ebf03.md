# ACRA

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 2e50984eb0ded91a50d83c78f226bfe4268e8d10de278703ecaf5644bb7d141b -->

ak'-ra, a'-kra (1 Macc 1:33 the Revised Version (British and American), "citadel"). See JERUSALEM.
