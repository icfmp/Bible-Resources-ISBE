# ADAMI-NEKEB

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: ea6c8bc58a4d1e201b9d313757ecc597ae3f8f9997c71f8bd8183863895abc96 -->

ad'-a-mi ne'-keb 'adhami ha-neqebh, "the ground of the piercing," (that is of the pass, or defile): A place mentioned in indicating the border of Naphtali (Jos 19:33). In the King James Version, Adami and Nekeb are given as separate names, and it is an open question which view of the matter is correct. Most of the Greek texts give the names as two. The Vulgate has "Adami quae est Neceb." The Jerusalem Talmud gives two names, though instead of Hannekeb or Nekeb it has Siyadathah (Meg 1 1, or Neubauer's Geog du Talmud, 225). In the list of places conquered by Thothmes III of Egypt occurs the name NQBU (Tomkins, Rec of Past, new series, V, 47), which seems to be the same with Neqeb.

The list of names for the border of Naphtali (Jos 19:33,34) has no name in common with the list of cities (Jos 19:35-38) unless Adami and Adamah are the same. The PE Survey maps locate Adamah at Damieh, about seven miles northwest of the exit of the Jordan from the Lake of Galilee, and Adami at Khurbet Adamah, five or six miles south of the exit. Conder, Tomkins and others place Adami at Damieh, and identify Nekeb by its Talmudic name in the neighboring ruin Seiyadeh. Conder says (art. "Nekeb," HDB) that the "pass" implied in the name Nekeb "is probably one leading from the eastern precipices near Tiberias."

Willis J. Beecher
