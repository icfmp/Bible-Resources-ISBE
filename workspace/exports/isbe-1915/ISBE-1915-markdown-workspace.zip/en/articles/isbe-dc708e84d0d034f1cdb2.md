# ABEL-MAIM

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 93ac06c5d3b2e9b6860e3b3716624200f6b9f05df6bf348f2dcd8e9388721742 -->

a'-bel-ma'-im ('abhel mayim, "meadow of water"). See ABEL-BETH-MAACAH.
