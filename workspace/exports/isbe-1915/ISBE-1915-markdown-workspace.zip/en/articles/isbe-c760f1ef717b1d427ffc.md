# ADORN

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 5d6db7934aad83de529ef63e75c79a1fa8bfb5e55461c5c948a10d18f8f7596f -->

a-dorn' (kosmeo): Has as its primary meaning "to arrange," "to put In order," "to decorate." It is used with reference to the manner in which Christian women were urged to dress. This was a vital question in the early church, and both Paul and Peter give advice on the subject (1Ti 2:9; 1Pe 3:3).

See DRESS.

Figurative: In Mt 12:44 the King James Version the word is translated "garnish" and is used in a figurative sense. It describes accurately the condition of the Jewish nation. Even though they have swept out idolatry and have adorned the life with much ceremony and endless religious prescriptions yet the evil spirit can say, "I will return to my house." This same thing has repeatedly been done by individuals and nations when reforms have been instituted, but Christ was not enthroned and the heart or nation was still dominated by evil. It is used also in a figurative sense with reference to the graces of the Christian life. When we remember how very highly Orientals esteem the adornment of the body, its use here becomes very forceful. It is this that makes Ps 45:13 of special significance as to the beauty and glory of the church as she is presented to God. See also Pr 1:9; 4:9; Isa 61:10; 1Pe 3:4,5. Consecration to God, the indwelling of His Spirit, righteousness, a meek and quiet spirit--these are the true adornments of the life. All these passages carry with them the idea of joy, the satisfaction that should be ours in these possessions.

Jacob W. Kapp
