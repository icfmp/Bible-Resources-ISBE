# AMZI

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: b6c37d90018d633443c8d6b822d82334cb539c715e5f378291344172f86b51f1 -->

am'-zi (`amtsi, "my strength"):

(1) A Levite of the family of Merari (1Ch 6:46).

(2) A priest of the family of Adaiah in the second temple. His father's name was Zechariah (Ne 11:12).
