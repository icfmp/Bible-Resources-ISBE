# AJALON

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 536acb83a7839ca13d7661a2d1c515c2d62d90289b5079b7e16f83b365ddbb59 -->

aj'-a-lon. See AIJALON.
