# AHOLIAB

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 81f4e7b1c17cd247e4768973ca069ced0b35b50c71127c53bd99806bcb159779 -->

a-ho-li'-ab. See OHOLIAB.
