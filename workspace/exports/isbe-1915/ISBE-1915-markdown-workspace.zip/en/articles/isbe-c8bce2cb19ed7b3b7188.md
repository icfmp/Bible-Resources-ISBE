# ACHISH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: f99e5a8c4c104bdcc7fa1a4059fabac253d7cd9bad2584955b768fe80d369462 -->

a'-kish ('akhish): King of the city of Gath in the days of David. His father's name is given as Maoch (1Sa 27:2), and Maacah (1Ki 2:39). David sought the protection of Achish when he first fled from Saul, and just after his visit to Nob (1Sa 21:10-15). Fearing rough treatment or betrayal by Achish, he feigned madness. But this made him unwelcome, whereupon he fled to the Cave of Adullam (1Sa 22:1). Later in his fugitive period David returned to Gath to be hospitably received by Achish (1Sa 27:1 ff), who gave him the town of Ziklag for his home. A year later, when the Philistines invaded the land of Israel, in the campaign which ended so disastrously for Saul (1Sa 31), Achish wished David to participate (1Sa 28:1-2), but the lords of the Philistines objected so strenuously, when they found him and his men with the forces of Achish, that Achish was compelled to send them back. Achish must have been a young man at this time, for he was still ruling forty years later at the beginning of Solomon's reign (1Ki 2:39). He is mentioned as Abimelech in the title of Ps 34. See ABIMELECH.

Edward Mack
