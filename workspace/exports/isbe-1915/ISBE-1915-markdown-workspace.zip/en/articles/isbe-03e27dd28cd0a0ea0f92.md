# ACHAR

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 889d15d85a24bdc554c258a032184bd5ed4dcd0c5522450a2352b5aad46d782f -->

a'-kar: Variant of ACHAN, which see.
