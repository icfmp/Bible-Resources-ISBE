# ADVERTISE

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: db5758b61e7b1b093e5d61e0459b605771aa758269c1ec770ff83a68fc3030a8 -->

ad'-ver-tiz: This word is found twice in the Old Testament: In Nu 24:14 (from Hebrew, ya`ats, "to advise") Balsam advises Balak of the future of Israel and its influence upon his kingdom ("I will advertise thee"). In the King James Version Ru 4:4 (from galah 'ozen, "to uncover the ear," "to reveal") Boaz in speaking to the nearer kinsman of Ruth: "I thought to advertise thee" (the Revised Version, margin "uncover thine ear").
