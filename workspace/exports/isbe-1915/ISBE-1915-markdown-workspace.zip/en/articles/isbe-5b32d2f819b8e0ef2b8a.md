# AEON

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 72a2eb8c8116b37d83f53077c64784748f08d0efba212b302ba07934f5588ed4 -->

e'-on: This word originally meant "duration," "dispensation." In the philosophy of Plato and Aristotle the word is aion, from which this word is transliterated. In the Gnostic philosophy it has a special meaning and is there used to solve the problem of the world order. In the infinite separation between God and the world, it was taught, there must of necessity be mediating powers. These powers are the eons and are the successive emanations from God from eternity. They are spiritual, existing as distinct entities. They constituted the Divine fullness or the Divine Pleroma. The name was applied to these beings for two reasons: because they were thought to partake of the eternal existence of God and because they were supposed to govern the various ages. The idea of the eons in various forms may be found in nearly all oriental philosophy that attempted to deal with the problem of the world order. It appears in the writings of Philo, in Shintoism, in the old Zoroastrian religion.

See GNOSTICISM.

Jacob W. Kapp
