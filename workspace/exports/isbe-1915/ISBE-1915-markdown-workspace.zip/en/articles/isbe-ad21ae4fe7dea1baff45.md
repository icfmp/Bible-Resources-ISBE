# ABISUM

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 978a14565741acac37f6f5dae38f0201a093f7c281914832e437db87c830cfd0 -->

ab'-i-sum. See ABISUE (Apocrypha).
