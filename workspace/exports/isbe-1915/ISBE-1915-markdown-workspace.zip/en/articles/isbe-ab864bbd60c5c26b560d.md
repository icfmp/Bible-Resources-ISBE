# AGE

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 605f1cce0eaffe5d974eb2b38c384dae5c1b2332db667625800c227557326180 -->

aj: A period of time or a dispensation. In the above sense the word occurs only once in the King James Version, in the sing, as the translation of dor, which means, properly, a "revolution" or "round of time," "a period," "an age" or "generation of man's life"; almost invariable translated "generation," "generations" (Job 8:8), "Inquire, I pray thee, of the former age"); we have the plural as the translation of aion, properly "duration," "the course or flow of time," "an age or period of the world," "the world" (Eph 2:7, "in the ages to come"; Col 1:26, "the mystery which hath been hid from ages and from generations," the English Revised Version, "from all ages," etc., the American Revised Version, margin, of geneai, "generations" (Eph 3:5 "generations," Eph 3:21, "unto all generations for ever and ever," Greek margin, "all the generations of the age of the ages"). "Ages is given in margin of the King James Version (Ps 145:13; Isa 26:4, "the rock of ages").

We have "age" in the above sense (2 Esdras 3:18; Tobit 14:5; aion) "ages," aion (1 Esdras 4:40 (of Truth) "she is the strength," etc., "of all ages"), genea, the Revised Version (British and American), "generation" (The Wisdom of Solomon 7:27; 1 Macc 2:61); Ecclesiasticus 24:33, eis geneas aionon, "generations of ages"; The Wisdom of Solomon 14:6, "generations' (geneseos).

Revised Version has "age" for "world" (Heb 6:5); "ages" for "worlds" (the Revised Version, margin Heb 1:2; the American Revised Version, margin; compare 1Ti 1:17) (margin, "unto the ages of the ages"), "ages" for "world" (1Co 10:11; Heb 9:26). the English Revised Version has "all ages" for "the beginning of the world " (Eph 3:9, the American Standard Revised Version "for ages"); "king of the ages" for "king of saints" (Re 15:3, corrected text; margin, many ancient authorities read "nations"; Jer 10:7).

See EVERLASTING.

W. L. Walker
