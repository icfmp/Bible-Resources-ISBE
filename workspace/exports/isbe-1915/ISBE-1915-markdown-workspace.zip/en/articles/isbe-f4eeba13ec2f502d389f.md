# ALPHA AND OMEGA

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: f2ade8e463c5052b45bbba05b06268596293e07f67c9232b6d21cd22baa5e7c9 -->

al'-fa, o'-me-ga, o-me'-ga (Alpha and Omega = A and O): The first and last letters of the Greek alphabet, hence, symbolically, "beginning and end"; in Revelation "The Eternal One" in Re 1:8 of the Father, in Re 21:6 and Re 22:13 of the Son. Compare Theodoret, Eusebius, Historia Ecclesiastica, iv. 8: "We used alpha down to omega, i.e. all." A similar expression is found in Latin (Martial, v.26). Compare Aretas (Cramer's Catenae Graecae in New Testament) on Re 1:8 and Tertullian (Monog, 5): "So also two Greek letters, the first and last, did the Lord put on Himself, symbols of the beginning and the end meeting in Him, in order that just as alpha rolls on to omega and omega returns again to alpha, so He might show that both the evolution of the beginning to the end is in Him and again the return of the end to the beginning." Cyprian, Testim, ii.1; vi.22, iii.100, Paulinus of Nola Carm. xix.645; xxx.89; Prudentius, Cathem., ix.10-12. In Patristic and later literature the phrase is regularly applied to the Son. God blesses Israel from 'aleph to taw (Le 26:3-13), but curses from waw to mem (Le 26:14-43). So Abraham observed the whole law from 'aleph to taw. Consequently, "Alpha and Omega" may be a Greek rendering of the Hebrew phrase, which expressed among the later Jews the whole extent of a thing.

J. E. Harry
