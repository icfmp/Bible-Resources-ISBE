# AIJELETH HASH-SHAHAR

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: cf8ce6d2ef6070b1405eacde05e55381d480377ade7729a5dffbc9d2af87a235 -->

a'-je-leth hash-sha'-har. See PSALMS; SONG.
