# AMASHSAI

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 7045655230c0f7bfbf97712c537ff2eb2a61fd1628d4c2e3809fe8e543d5ba8e -->

a-mash'-si `amashcay, probably a textual error for `amashay; the ("s") implies a reading `-M-C-Y, based on a mistaken derivation from '-M-C. The original reading may have been `ammishay; compare AMASAI): Amashsai is a priestly name in the post-exilic list of inhabitants of Jerusalem (Ne 11:13; Maasai, 1Ch 9:12); the reading in Chronicles is ma`asay, the King James Version "Maasiai," the Revised Version (British and American) "Maasai."
