# ALIAN

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 3a702e3538b74e74f4f7f4483ab376b8f2581c7391e26c895d334cdb34d20ddf -->

a-li'-an (`alyan): A descendant of Esau, and son of Shobal (1Ch 1:40). In the corresponding earlier genealogy (Ge 36:23) the same person is given as Alvan (`alwan), the change of the third consonant being a simple one, common to Hebrew, occurring similarly in Aliah (which see). Alian is not to be identified with Aliah, since the groups of names in which these occur are quite different, and the context in each case is not the same.
