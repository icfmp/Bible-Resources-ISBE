# ACUD

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: be4f6edcd1a2d26aed27f168bb2cf542d6e51bb3891bf402021d1918622ee6fc -->

a'-kud (Akoud; the King James Version Acua) = AKKUB (Ezr 2:45) which see; omitted in Ne 7: The descendants of Acud (temple-servants) returned with Zerubbabel to Jerusalem (1 Esdras 5:30).
