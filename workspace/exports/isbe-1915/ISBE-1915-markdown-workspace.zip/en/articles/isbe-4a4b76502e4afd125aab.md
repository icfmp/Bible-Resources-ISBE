# ABIRAM

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: a751571834256c1b8db52f49befdb7e40d38a6361a8463add364f0e1b37be01e -->

a-bi'-ram ('abhiram, "exalted father," or, "my father is an exalted one"):

(1) The son of Eliab the son of Pallu the son of Reuben (Nu 26:5 ff; De 11:6). In company with his brother Dathan and Korah the Levite and others, he disputed the authority of Moses and Aaron in the wilderness (Nu 16-17; 26; De 11:6; Ps 106:17). Two hundred and fifty followers of Korah perished by fire at the doorway of the tent of meeting. Dathan and Abiram refused to come to the tent of meeting, at the summons of Moses; and the earth opened where their tents were, and swallowed them and their families and their goods. See KORAH.

(2) The firstborn son of Hiel the Bethelite, who rebuilt Jericho in the time of Ahab (1Ki 16:34; compare Jos 6:26). This incident has recently acquired a new interest owing to discoveries made at Gezer and Megiddo concerning foundation sacrifices as in ancient times offered in Palestine. One should not be too positive in making statements concerning this, but the following is a possible interpretation of the record. The curse pronounced by Joshua on the man who should rebuild Jericho was of a piece with the other details, Jericho being treated exceptionally, as a city placed under the ban. The language of Joshua's curse is capable of being translated: `Cursed be the man before Yahweh who shall .... build .... Jericho; (who) shall lay its foundation in his firstborn, and set up its gates in his youngest.' According to this interpretation the death of the builder's eldest and youngest sons is not spoken of as the penalty involved in the curse, but as an existing horrible custom, mentioned in order to give solemnity to the diction of the curse. The writer in Kings cites the language of the curse by Joshua. The context in which he mentions the affair suggests that he regards Hiel's conduct as exceptionally flagrant in its wickedness. Hiel, in defiance of Yahweh, not only built the city, but in building it revived the horrible old Canaanite custom, making his first-born son a foundation sacrifice, and his youngest son a sacrifice at the completion of the work.

Willis J. Beecher
