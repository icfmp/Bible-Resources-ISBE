# ANAIAH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 533e8b1ec1cc664659fd1bd878b6dd362516e0d8254bffe1138f2fb69d490e9f -->

an-a-i'-a, a-ni'-a (`anayah, "Yah has answered"):

(1) a Levite who assisted Ezr in reading the law to the people (Ne 8:4), perhaps the person called Ananias in Esdras 9:43.

(2) One of those who sealed the covenant (Ne 10:22). He may have been the same as Anaiah (1).
