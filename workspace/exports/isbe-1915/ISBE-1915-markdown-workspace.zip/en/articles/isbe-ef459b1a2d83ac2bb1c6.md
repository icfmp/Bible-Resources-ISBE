# ADMINISTER; ADMINISTRATION

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: fa6e98dc234c64462b2494f24b56001b73ce46d9beb6ada047af2f3f7a269a75 -->

ad-min'-is-ter ad-min-is-tra'-shun diakoneo, diakonia: Terms used in the King James Version in 1Co 12:5; 2Co 8:19,20; 2Co 9:12 respectively, and replaced in the Revised Version (British and American) by "minister" and "ministration." The root idea of both words is "service," hence to supply, or conduct or attend to anything; the performance of official duty, the conduct of affairs, the various forms of spiritual or social service. "Minister," used either of an act or of an office, is the term that best represents the apostolic thought and ideal.

Dwight M. Pratt
