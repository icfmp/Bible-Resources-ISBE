# ABDA

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 4a960ea1fc8f2095868911b2b4317a6bf4362be6bc5d7b5ddbf0b78efc2f97e8 -->

ab'-da (`abhda', perhaps, by abbreviation, "servant of Yahweh"):

(1) The father of Adoniram, King Solomon's superintendent of forced labor (1Ki 4:6).

(2) A Levite mentioned in the statistical note in (Ne 11:17). This "Abda the son of Shammua" is in the partly duplicate passage in (1Ch 9:16) called "Obadiah the son of Shemaiah."
