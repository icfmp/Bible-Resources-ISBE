# ACHIAS

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 5993fe679c87f722b62925f8873c02869f8874deacd16f6653740a3c25bca621 -->

a-ki'-as: An ancestor of Ezra (2 Esdras 1:2). Omitted in other genealogies.
