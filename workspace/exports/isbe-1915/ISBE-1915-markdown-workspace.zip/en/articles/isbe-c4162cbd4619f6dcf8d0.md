# ACTS OF PILATE

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 1a454e5757da86082fcb5e0c7c2f4309b65b93bb7403cabeaf69526d1f684b99 -->

pi'-lat, pi'-lat. See APOCRYPHAL GOSPELS.
