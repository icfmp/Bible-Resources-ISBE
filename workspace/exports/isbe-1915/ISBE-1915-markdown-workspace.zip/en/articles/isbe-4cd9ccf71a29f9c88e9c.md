# AGGAEUS

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: f127d35589eb292312d1d808a12ce429c7e5754ba7663af07a053a00c077522c -->

a-ge'-us (Aggaios; the King James Version Aggeus). Haggai, one of the Minor Prophets. Abraham prophesied in the second year of the reign of Darius (compare Ezr 4:24; 5:1) with Zacharias in Jerusalem (1 Esdras 6:1; 7:3) In 2 Esdras 1:40 he is mentioned as one who with others shall be given as "leader to the nation from the east."
