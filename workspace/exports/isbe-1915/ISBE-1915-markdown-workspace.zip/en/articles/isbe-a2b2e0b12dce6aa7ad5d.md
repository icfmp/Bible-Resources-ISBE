# ADORATION

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 44a9da7253e23ea6df47b1d4e336c6873cb2e02d8f18ce6c5fd1b1df77c7ae3c -->

ad-o-ra'-shun: Though this word never occurs in English Versions, it represents aspects of worship which are very prominent in the Bible.

I. Etymology.

The word is derived from Latin adorare =

(1) "to speak to,"

(2) "to beseech," "entreat,"

(3) "to do homage," "to worship"; from the Latin, os (oris), mouth.

Some have supposed that the root os points to the Roman practice of applying the hand to the mouth, i.e. kissing the hand to (a person or thing), as a token of homage.

II. Meaning.

Adoration is intense admiration culminating in reverence and worship, together with the outward acts and attitudes which accompany such reverence. It thus includes both the subjective sentiments, or feelings of the soul, in the presence of some superior object or person, and the appropriate physical expressions of such sentiments in outward acts of homage or of worship. In its widest sense it includes reverence to beings other than God, especially to monarchs, who in oriental countries were regarded with feelings of awe. But it finds its highest expression in religion. Adoration is perhaps the highest type of worship, involving the reverent and rapt contemplation of the Divine perfections and prerogatives, the acknowledgment of them in words of praise, together with the visible symbols and postures that express the adoring attitude of the creature in the presence of his Creator. It is the expression of the soul's mystical realization of God's presence in His transcendent greatness, holiness and lovingkindness. As a form of prayer, adoration is to be distinguished from other forms, such as petition, thanksgiving, confession and intercession.

III. Outward Postures.

In the Old Testament and New Testament, these are similar to those which prevailed in all oriental countries, as amply illustrated by the monuments of Egypt and Assyria, and by the customs still in use among the nations of the East. The chief attitudes referred to in the Bible are the following:

1. Prostration:

Among the Orientals, especially Persians, prostration (i.e. falling upon the knees, then gradually inclining the body, until the forehead touched the ground) was common as an expression of profound reverence and humility before a superior or a benefactor. It was practiced in the worship of Yahweh (Ge 17:3; Nu 16:45; Mt 26:39, Jesus in Gethsemane; Re 1:17), and of idols (2Ki 5:18; Da 3:5,6), but was by no means confined to religious exercises. It was the formal method of supplicating or doing obeisance to a superior (eg 1Sa 25:23 f; 2Ki 4:37; Es 8:3; Mr 5:22; Joh 11:32).

2. Kneeling:

A substitute for prostration was kneeling, a common attitude in worship, frequently mentioned in Old Testament and New Testament (eg 1Ki 8:54; Ezr 9:5; Ps 95:6; Isa 45:23; Lu 22:41, Christ in Gethsemane; Ac 7:60; Eph 3:14). The same attitude was sometimes adopted in paying homage to a fellow-creature, as in 2Ki 1:13. "Sitting" as an attitude of prayer (only 2Sa 7:18 parallel 1Ch 17:16) was probably a form of kneeling, as in Mahometan worship.

3. Standing:

This was the most usual posture in prayer, like that of modern Jews in public worship. Abraham "stood before Yahweh (Yahweh)" when he interceded for Sodom (Ge 18:22). Compare 1Sa 1:26. The Pharisee in the parable "stood and prayed" (Lu 18:11), and the hypocrites are said to "pray standing in the synagogues, and in the corners of the streets" (Mt 6:5 the King James Version).

4. The Hands:

The above postures were accompanied by various attitudes of the hands, which were either lifted up toward heaven (Ps 63:4; 1Ti 2:8), or outspread (Ex 9:29; Ezr 9:5; Isa 1:15), or both (1Ki 8:54).

5. Kiss of Adoration:

The heathen practice of kissing hands to the heavenly bodies as a sign of adoration is referred to in Job 31:27, and of kissing the idol in 1Ki 19:18; Ho 13:2. The kiss of homage is mentioned in Ps 2:12, if the text there be correct. Kissing hands to the object of adoration was customary among the Romans (Pliny xxviii.5). The New Testament word for "worship" (proskuneo) literally means to kiss (the hand) to (one).

See also ATTITUDES.

IV. Objects of Adoration.

The only adequate object of adoration is the Supreme Being. He only who is the sum of all perfections can fully satisfy man's instincts of reverence, and elicit the complete homage of his soul.

1. Fellow-Creatures:

Yet, as already suggested, the crude beginnings of religious adoration are to be found in the respect paid to created beings regarded as possessing superior claims and powers, especially to kings and rulers. As instances we may mention the woman of Tekoa falling on her face to do obeisance to king David (2Sa 14:4), and the king's servants bowing down to do reverence to Haman (Es 3:2). Compare Ru 2:10; 1Sa 20:41; 2Sa 1:2; 14:22.

2. Material Objects:

On a higher plane, as involving some recognition of divinity, is the homage paid to august and mysterious objects in Nature, or to phenomena in the physical world which were supposed to have some divine significance. To give reverence to material objects themselves is condemned as idolatry throughout the Old Testament. Such an example is the case with the worship of "the host of heaven" (the heavenly bodies) sometimes practiced by the Hebrews (2Ki 17:16; 21:3,5). So Job protests that he never proved false to God by kissing hands to the sun and moon in token of adoration (Job 31:26-28). We have reference in the Old Testament to acts of homage paid to an idol or an image, such as falling down before it (Isa 44:15,17,19; Da 3:7), or kissing it (1Ki 19:18; Ho 13:2). All such practices are condemned in uncompromising terms. But when material things produce a reverential attitude, not to themselves, but to the Deity whose presence they symbolize, then they are regarded as legitimate aids to devotion; eg. fire as a manifestation of the Divine presence is described as causing the spectator to perform acts of reverence (eg. Ex 3:2,5; Le 9:24; 1Ki 18:38 f). In these instances, it was Yahweh Himself that was worshipped, not the fire which revealed Him. The sacred writers are moved to religious adoration by the contemplation of the glories of Nature. To them, "the heavens declare the glory of God, and the firmament sheweth his handiwork." (Compare especially the "nature Psalms" Ps 8; 19; 29; 104.)

3. Angels:

On a still higher plane is the adoration practiced in the presence of supernatural agents of the Divine will. When an angel of God appeared, men fell instinctively before him in reverence and awe (eg. Ge 18:2; 19:1; Nu 22:31; Jud 13:20; Lu 24:4,5). This was not to worship the creature instead of the Creator, for the angel was regarded, not as a distract individual having an existence and character of his own, but as a theophany, a self-manifestation of God.

4. The Deity:

The highest form of adoration is that which is directed immediately to God Himself, His kingly attributes and spiritual excellencies being so apprehended by the soul that it is filled with rapture and praise, and is moved to do Him reverence. A classical instance is the vision that initiated Isaiah into the prophetic office, when he was so possessed with the sovereignty and sublimity of God that he was filled with wonder and self-abasement (Isa 6:1-5). In the Old Testament, the literature of adoration reaches its high-water mark in the Psalms (compare especially the group Psalms 95-100), where the ineffable majesty, power and holiness of God are set forth in lofty strains. In the New Testament, adoration of the Deity finds its most rapturous expression in Rev, where the vision of God calls forth a chorus of praise addressed to the thrice-holy God (4:8-11; 7:11,12), with whom is associated the Redeemer-Lamb.

5. Jesus Christ:

How far is Jesus regarded in the New Testament as an object of adoration, seeing that adoration is befitting only to God? During our Lord's lifetime He was often the object of worship (Mt 2:11; 8:2; 9:18; 14:33; 15:25; 20:20; 28:9,17; Mr 5:6; Joh 9:38). Some ambiguity, however, belongs to the Greek word proskunein, for while it is the usual word for "worshipping" God (eg. Joh 4:24), in some contexts it means no more than paying homage to a person of superior rank by kneeling or prostration, just as the unmerciful servant is said to have `fallen down and worshipped' his master the king (Mt 18:26), and as Josephus speaks of the Jewish high priests as proskunoumenoi (BJ, IV, v, 2). On the other hand, it certainly implies a consciousness, on the part of those who paid this respect to Jesus, and of Jesus Himself, of a very exceptional superiority in His person, for the same homage was refused by Peter, when offered to him by Cornelius, on the ground that he himself also was a man (Ac 10:25 f), and even by the angel before whom John prostrated himself, on the ground that God alone was to be "worshipped" (Re 22:8,9).

Yet Jesus never repudiated such tokens of respect. But whatever about the "days of His flesh," there is no doubt that after the ascension Christ became to the church the object of adoration as Divine, and the homage paid to Him was indistinguishable in character from that paid to God. This is proved not only by isolated passages, but still more by the whole tone of the Ac and epistles in relation to Him. This adoration reaches its highest expression in Re 5:9-14, where the Redeemer-Lamb who shares the throne of God is the subject of an outburst of adoring praise on the part of the angelic hosts. In Re 4:8-11 the hymn of adoration is addressed to the Lord God Almighty, the Creator; here it is addressed to the Lamb on the ground of His redeeming work. In Re the adoration of Him "who sitteth on the throne" and that of "the Lamb" flow together into one stream of ecstatic praise (compare Re 7:9-11).

D. Miall Edwards
