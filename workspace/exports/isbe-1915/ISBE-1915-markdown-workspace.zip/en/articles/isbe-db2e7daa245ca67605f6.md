# ADIEL

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 8a3734fa239aa60a11274b03d9c97b29e0ffe76d972717c926379fe5bab8b88a -->

ad'-i-el (`adhi'el, "ornament of God"):

(1) One of the "princes" of the tribe of Simeon, who, in the days of Hezekiah, smote the aborigines of Gedor and captured the valley (1Ch 4:36 ff).

(2) Father of Maasai, one of the priests who dwelt in Jerusalem after the return from the Exile (1Ch 9:12).

(3) Father of Azmaveth who was over David's treasures (1Ch 27:25).
