# AESORA

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: ec0bd44b556b613ff3cdef7ef0516f7638414e5cd029d3ebbd01757d6a823fe1 -->

e'-so-ra, the King James Version Esora, e-so'-ra (Aisora): A town in the borders of Samaria, mentioned in connection with Beth-boron and Jericho (Judith 4:4), and from this association we judge that it was in the eastern part of Samaria.
