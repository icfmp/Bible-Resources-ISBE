# ADAM, CITY OF

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 80ff80239c813ba058cc134c0ff4cd8affbe45acc509c2acd15fc8e015d819c4 -->

('adham, "red" or BDB "made"): A city in the middle of the Jordan valley near ZARETHAN (Jos 3:16), which see. The name probably survives at the Damieh Ford, near the mouth of the Jabbok twenty miles above Jericho. An Arabian historian asserts that about 1265 AD the Jordan was here blocked by a land slide. The inner gorge of the Jordan is here narrow with high banks which would facilitate such an obstruction as permitted the waters to "pile up" above to Adam and run out below, permitting Joshua's host to cross on dry land (SWP, II, 15; Wright, SCOTH, 130-34).

George Frederick Wright
