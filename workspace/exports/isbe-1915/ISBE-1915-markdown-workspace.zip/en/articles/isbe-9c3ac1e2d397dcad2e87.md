# AIRUS

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 302ea4922bd269aaaa4c55cac9f4e7c42694d86383e59515c4e826e6de283295 -->

a-i'-rus, ar'-us (Iairos): the King James Version, one of the heads of a family of temple servants (1 Esdras 5:31 the Revised Version (British and American) JAIRUS), which returned from Babylon with Zerubbabel; in the Old Testament called Reaiah (Ezr 2:47; Ne 7:50), and classed among the Nethinim.
