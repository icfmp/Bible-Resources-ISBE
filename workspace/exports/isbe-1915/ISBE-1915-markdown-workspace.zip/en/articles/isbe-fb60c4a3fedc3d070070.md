# ACKNOWLEDGE

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 0414013ffe61c3a082ef90f459ccbc09fbf797a312251171672d19e5e0e2cb9c -->

ak-nol'-ej (gignosko): To declare that one recognizes the claims of a person or thing fully established. Both in Old Testament and New Testament expressed by various forms of the word "know" (Pr 3:6; Isa 61:9; Col 2:2 the King James Version). The Psalmist (Ps 32:5) "acknowledged" his sin, when he told God that he knew the guilt of what he had done. The Corinthians (2Co 1:14) "acknowledged" Paul and his companions when they formally recognized their claims and authority.
