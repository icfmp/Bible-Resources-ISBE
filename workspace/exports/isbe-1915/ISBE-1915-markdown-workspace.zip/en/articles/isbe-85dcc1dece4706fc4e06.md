# ADADRIMMON

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 584bdeec885f472e74351d62ecbc691986ab67499b4abe01bbedea073d5ca541 -->

a-dad-rim'-on: Shorter and less accurate name of a place in the Valley of Megiddo, which tradition connected with the death of King Josiah (Zec 12:11; 2Ch 35:22). See HADADRIMMON.
