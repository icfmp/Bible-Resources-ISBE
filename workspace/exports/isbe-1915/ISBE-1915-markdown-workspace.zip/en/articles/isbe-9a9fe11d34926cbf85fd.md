# AMASAI

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 8aea1ecab834927a483db48dd9faa72d01f90f20bdbe2a89df808bab673eb8f8 -->

a-ma'-si (`amasay, perhaps rather to be read `ammishay; so Wellhausen, IJG, II, 24, n.2):

(1) A name in the genealogy of Kohath, son of Elkanah, a Levite of the Kohathite family (compare 1Ch 6:25; 2Ch 29:12).

(2) Chief of the captains who met David at Ziklag and tendered him their allegiance. Some have identified him with Amasa and others with Abishai, who is called Abshai in 1Ch 11:20 m (compare 1Ch 18:12). The difficulty is that neither Amasa nor Abishai occupied the rank of the chief of thirty according to the lists in 2Sa 23 and 1Ch 11, the rank to which David is supposed to have appointed into (compare 1Ch 12:18).

(3) One of the trumpet-blowing priests who greeted David when he brought back the Ark of the Covenant (compare 1Ch 15:24).
