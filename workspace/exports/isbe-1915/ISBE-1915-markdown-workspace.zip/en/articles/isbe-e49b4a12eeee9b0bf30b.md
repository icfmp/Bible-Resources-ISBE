# AMAN

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 98365c005ada1bc0ab6e83df3082ac70fee270979d750cac353fd5eb78d484a0 -->

a'-man (Aman; Codex Vaticanus reads Adam): Tobit 14:10; Additions to Esther 12:6; 16:10,17, probably in each case for Haman, the arch-enemy of the Jews in the canonical Book of Esther (compare Es 3:1 with Additions to Esther 12:6). In Additions to Esther (16:10) Aman is represented as a Macedonian, in all other points corresponding to the Haman of the Book of Esther.
