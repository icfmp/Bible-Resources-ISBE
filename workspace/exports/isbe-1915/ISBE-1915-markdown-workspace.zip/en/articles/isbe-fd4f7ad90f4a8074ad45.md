# ADMAH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 2171da1e00afb09b079deddda1b8a32c8717046612b9dc8dd49cc0ebbdf658da -->

ad'-ma ('adhmah): From a root signifying red; one of the Cities of the Plain (Ciccar) (Ge 10:19; 14:2,8; De 29:23; Ho 11:8) upon which Abraham and Lot looked from the heights of Bethel; destroyed with Sodom and Gomorrah. Conder tentatively identifies it with the City of Adam referred to in Jos 3:16, and thinks that perhaps the name may be preserved in that of Damieh Ford, near the mouth of the river Jabbok; but that point could not have been in view from Bethel.

See VALE OF SIDDIM.
