# ABROAD

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 28178dacf9f1af0c2734b933791a254d04b58ec5194c299fc67b278540f2766a -->

a-brod: An idiomatic rendering of aphiketo (literally, "arrived"), "come abroad" is used in Ro 16:19 to indicate a report that has been most widely diffused (literally, "did reach unto all"). Similar idiomatic translations of the King James Version have been replaced in the Revised Version (British and American) by those more literal, as in Mr 4:22; Lu 8:17; Mr 6:14; 1Th 1:8. Used also in other idiomatic renderings, as "spread abroad" diaphemizo, Mr 1:45; "noised abroad" dialaleo, Lu 1:65; "scattered abroad," Joh 11:52; Ac 8:1, etc.; in all these cases for the pervasive meaning of the Greek preposition in composition. In Ge 15:5, chuts means "outside."

H. E. Jacobs
