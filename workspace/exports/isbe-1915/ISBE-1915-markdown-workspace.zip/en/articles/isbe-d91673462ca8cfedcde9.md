# ABEL-MIZRAIM

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: f943d02bdc8eb3018adea5f5736d6d09e4410dbeb37ba12bc84d624d8f901579 -->

a'-bel-miz'-ra-im ('abhel mitsrayim, "meadow of Egypt"): A name given to "the threshing floor of Atad," East of the Jordan and North of the Dead Sea, because Joseph and his funeral party from Egypt there held their mourning over Jacob (Ge 50:11). The name is a pun. The Canaanite residents saw the 'ebhel, "the mourning," and therefore that place was called 'abhel mitsrayim.

It is remarkable that the funeral should have taken this circuitous route, instead of going directly from Egypt to Hebron. Possibly a reason may be found as we obtain additional details in Egyptian history. The explanations which consist in changing the text, or in substituting the North Arabian Mutsri for Mitsrayim, are unsatisfactory. Willis J. Beecher
