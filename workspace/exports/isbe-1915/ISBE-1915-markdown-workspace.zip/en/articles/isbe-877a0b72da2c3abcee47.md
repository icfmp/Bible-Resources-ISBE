# ADNAH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 92e4a76f5e52af2400674fd13cba3340b195091f5b5f2e7df2ade69d130b6101 -->

ad'-na (`adhnach, "pleasure"; Edna):

(1) A warrior of the tribe of Manasseh, who deserted Saul and joined David's forces at Ziklag (1Ch 12:20,21)

(2) An officer of high rank, perhaps the commander-in-chief of Jehoshaphat's army (2Ch 17:14). Here the spelling in Hebrew is `adhnah.
