# AIJALON

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: fea38cb44c9e4d68a051820a690a6221c9fef2bd3771bceae7ce30195e6c0fdb -->

a'-ja-lon ('ayyalon, "deerplace"; the King James Version, Ajalon (Jos 10:12)):

(1) The name of a town allotted to the tribe of Da (Jos 19:42), which was also designated a Levitical city (Jos 21:24), which fell to the Sons of Kohath (1Ch 6:69). The first mention of Aijalon is in the narrative of Joshua's defeat of the five Amorite kings: "thou, Moon, in the valley of Aijalon" (Jos 10:12). The Danites failed to take it from the Amorites (Jud 1:35), although the men of Ephraim held it in vassalage. Here Saul and Jonathan won a great victory over the Philistines (1Sa 14:31). At one time it was held by the tribe of Benjamin (1Ch 8:13). Rehoboam fortified it against the kingdom of Israel (2Ch 11:10). In the days of King Ahaz it was captured by the Philistines (2Ch 28:18). It has been identified with the modern Yalo; its antiquity goes back to Tell el-Amarna Letters, in which it has mention. It Is situated Northwest of Jerusalem in a valley of the same name, which leads down from the mountains to the sea.

(2) A town in the tribe of Zebulun, site unknown, where Elon the judge was buried (Jud 12:12).

Edward Mack
