# ABIHAIL

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: f96ede5427e4cbb6a3d019b9c0c6edaaea5a4160fe7e29b20a311f07ecbe56f3 -->

ab'-i-hal ('abhichayil; in some manuscripts 'abhihayil, when feminine, but best reading is the former: "father, or cause, of strength"): Five persons in the Old Testament are called by this name:

(1) A Levite and the father of Zuriel, who in the Wilderness was head of the house of Merari, Levi's youngest son (Nu 3:35);

(2) The wife of Abishur, a man of the tribe of Judah, in the line of Hazron and Jerahmeel (1Ch 2:29);

(3) One of the heads of the tribe of Gad, who dwelt in Gilead of Bashan (1Ch 5:14);

(4) Either a wife of Rehoboam, king of Judah, or mother of his wife Mahalath, according to the interpretation of the text (2Ch 11:18); probably the latter view is correct, since there is no conjunction in the text, and since (2Ch 11:19) contemplates only one wife as already mentioned. This being true, she was the wife of Jerimath, a son of David, and daughter of Eliab, David's eldest brother. It is interesting to note this frequent intermarriage in the Davidic house;

(5) Father of Queen Esther, who became wife of Xerxes (Biblical Ahasuerus) king of Persia, after the removal of the former queen, Vashti, (Es 2:15; 9:29). He was uncle of Mordecai.

Edward Mack
