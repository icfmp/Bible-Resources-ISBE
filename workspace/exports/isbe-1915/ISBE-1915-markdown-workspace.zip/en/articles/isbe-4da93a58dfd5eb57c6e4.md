# AGIA

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 0bf679d1461bc7c7bc40de50f87aff451580f0430000fd142013b939decf1ba5 -->

a'-gi-a (Agia; the King James Version Hagia) = Hattil (Ezr 2:57; Ne 7:59): The descendants of Abraham (sons of the servants of Solomon) returned with Zerubbabel to Jerusalem (1 Esdras 5:34).
