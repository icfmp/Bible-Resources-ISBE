# AARONITES

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 184d6e5a1546621674d734b2c64a4ec4f099abc8be5decda756f997120e72d89 -->

ar'-on-its (le-'aharon, literally, "belonging to Aaron"): A word used in the King James Version, but not in the revised versions, to translate the proper name Aaron in two instances where it. denotes a family and not merely a person (1Ch 12:27; 27:17). It is equivalent to the phrases "sons of Aaron," "house of Aaron," frequently used in the Old Testament. According to the books of Jos and Chronicles the "sons of Aaron," were distinguished from the other Levites from the time of Joshua (e.g. Jos 21:4,10,13; 1Ch 6:54).
