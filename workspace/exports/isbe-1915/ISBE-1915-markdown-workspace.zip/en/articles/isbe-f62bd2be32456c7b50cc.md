# ALIENATE

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 2c264a27ce310d317cfdbbcca3e01a8e1d3d9ea404c90a9edfe66155d9135b23 -->

al'-yen-at (`abhar; apallotrioo, "to estrange from"): In Old Testament, for the break between husband and wife caused by unfaithfulness to the marriage vow (Jer 6:8; Eze 23:17); also applied to the diversion of property (Eze 48:14). In New Testament, spiritually, for the turning of the soul from God (Eph 2:12; Col 1:21). The Greek allotrios, which is the root of the verb, is the opposite of id-i-os, "one's own." The word implies a former state, whence the person or thing has departed, and that, generally, by deterioration.
