# ADVERSITY

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 879d1a214fbd1d858922fa2fc70e30fc95d93f5b47c464384935cd16b6a3e718 -->

ad-vur'-si-ti: In the Revised Version (British and American) exclusively an Old Testament term, expressing the various forms of distress and evil conveyed by four Hebrew words: tsela`, "a halting" or "fall"; tsarah, "straits" "distress," "affliction"; tsar, "straitness," "affliction"; ra`, "bad," "evil," "harmful." These words cover the whole range of misfortunes caused by enemies, poverty, sorrow and trouble. "Adversity," which occurs once in the King James Version in New Testament (Heb 13:3: kakouchoumenos, "ill-treated") is displaced in the Revised Version (British and American) by the literal rendering which illustrates or interprets a common phase of adversity.

Dwight M. Pratt
