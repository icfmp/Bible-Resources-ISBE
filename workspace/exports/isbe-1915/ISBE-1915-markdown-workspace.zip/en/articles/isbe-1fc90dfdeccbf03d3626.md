# ALLELUIA

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: b6afe6282b7457a27e2b540e426c15b5e7a67d56d33050655bddcaa4f92838f7 -->

al-e-loo'-ya. See HALLELUJAH.
