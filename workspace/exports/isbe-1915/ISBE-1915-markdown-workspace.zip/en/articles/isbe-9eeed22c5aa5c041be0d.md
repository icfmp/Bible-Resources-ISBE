# ADINO

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 3a4100fcf45285bb6566e5292266df9ee4d1b8bf78ab20c84907bf09b3c2c7be -->

ad'-i-no, a-di'-no (`adhino, "his adorned one"): The senior of David's "mighty men." "Josheb-basshebeth a Tahchemonite, chief of the captains; the same was Adino the Eznite, against eight hundred slain at one time" (2Sa 23:8). This very exact rendering makes it evident even to an English reader that the text is imperfect. Ginsburg offers a corrected form taken substantially from the parallel passage in 1Ch 11:11: "Jashobeam a son of a Hachmonite, chief of the captains; he lifted up his spear." This is plausible, and is very generally accepted, and eliminates the names Adino and Eznite, which do not occur elsewhere in the Bible. Some of the facts are against this. The Septuagint has the names Adino and Eznite. The Latin finds no proper names in the passage, but so translates the words as to presuppose the Hebrew text as we have it. It may be a case for suspended judgment.

The texts concerning David's mighty men are fragmentary both in Samuel and in Chronicles. If they were more complete they would perhaps make it clear that the three seniors were comrades of David at Pas-dammim, Ephes- dammim (1Ch 11:13; 1Sa 17:1); and that we have in them additional details concerning that battle. The record says that on the death of Goliath the Philistines fled and the Israelites pursued (1Sa 17:52 ff), but it is not improbable that during the retreat portions of the Philistine force rallied, so that there was strenuous fighting.

Willis J. Beecher
