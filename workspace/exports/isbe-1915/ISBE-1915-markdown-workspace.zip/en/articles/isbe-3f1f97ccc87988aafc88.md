# AHIRAMITE

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: d91f40336e58bf5652aa4d35893c90f9311560967c75476836c2764c77c47f5b -->

a-hi'-ram-it ('achirami, "of the family of Ahiram"; Nu 26:38). See AHIRAM.
