# ALCIMUS

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 9ca2ea98405e162be1987ac4a0ded2422904838cc25badd0c6d9d0b055d297ad -->

al'-si-mus ('elyaqum, "God will rise"; Alkimos, "valiant"): A high priest for three years, 163-161 BC, the record of whose career may be found in 1 Macc 7:4-50; 9:1-57; 2 Macc 14; see also Ant, XII, 9-11; XX, 10. He was a descendant of Aaron, but not in the high-priestly line (1 Macc 7:14; also Ant, XX, 10); and being ambitious for the office of high priest, he hastened to Antioch to secure the favor and help of the new king, Demetrius, who had just overthrown Antiochus Eupator and made himself king. Alcimus was of the Grecianizing party, and therefore bitterly opposed by the Maccabees. Demetrius sent a strong army under Bacchides to establish him in the high-priesthood at Jerusalem. The favor with which Alcimus was received by the Jews at Jerusalem on account of his Aaronic descent was soon turned to hate by his cruelties. When Bacchides and his army returned to Antioch, Simon Maccabeus attacked and overcame Alcimus, and drove him also to Syria. There he secured from Demetrius another army, led by Nicanor, who, failing to secure Simon by treachery, joined battle with him, but was defeated and killed. A third and greater army, under Bacchides again, was dispatched to save the falling fortunes of Alcimus. Now Simon was overwhelmed and slain, Alcimus established as high priest and a strong force left in Jerusalem to uphold him. But he did not long enjoy his triumph, since he died soon after from a paralytic stroke.

Edward Mack
