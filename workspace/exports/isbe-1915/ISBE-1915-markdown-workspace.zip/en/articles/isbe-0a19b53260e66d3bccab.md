# ALABASTER

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: ac7a2a7cafc93ab12e6847e6e01f34d21985a7797348dae5a9eeeb7434106ddf -->

al'-a-bas-ter (alabastron (Mt 26:7; Mr 14:3; Lu 7:37)): In modern mineralogy alabaster is crystalline gypsum or sulphate of lime. The Greek word alabastron or alabastos meant a stone casket or vase, and alabastites was used for the stone of which the casket was made. This stone was usually crystalline stalagmitic rock or carbonate of lime, now often called oriental alabaster, to distinguish it from gypsum. The word occurs in the Bible only in the three passages of the Synoptic Gospels cited above. See BOX.
