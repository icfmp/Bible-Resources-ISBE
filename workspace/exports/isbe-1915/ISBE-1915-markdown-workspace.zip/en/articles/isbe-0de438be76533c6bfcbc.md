# ACCARON

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: a6b0981d41f15a9b6e2955e7bce070e4df66aed19a653ea193cddc57dcd60e3d -->

ak'-a-ron (Akkaron): Mentioned in 1 Macc 10:89 the King James Version; a town of the Philistines, known as Ekron (`eqron) in Old Testament, which King Alexander gave to Jonathan Maccabeus as a reward for successful military service in western Palestine. It is also mentioned in the days of the Crusades. See EKRON.
