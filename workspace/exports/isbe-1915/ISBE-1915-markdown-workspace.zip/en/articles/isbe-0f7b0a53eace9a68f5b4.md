# AGAIN

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: ba8353fd09a2248cfa6f09ef5c73dd9d037eb24a945614e05e31a187e4bab047 -->

a-gen': Advb. denoting repetition; in New Testament, generally for palin, "back," "once more." Occasionally, it has the force of a connective, synonymous with "moreover," as in Ro 15:10 ff; 1Co 3:20, etc. The expression "born again" of the King James Version, Joh 3:3,7; 1Pe 1:23, translating the Greek "anothen" and "ana" in composition, becomes in the Revised Version (British and American) "anew," i.e. "over again." As these particles mean "from above" and "up," their use as indicating repetition is sometimes disputed, but without further foundation than that "again" does not exhaust the meaning.
