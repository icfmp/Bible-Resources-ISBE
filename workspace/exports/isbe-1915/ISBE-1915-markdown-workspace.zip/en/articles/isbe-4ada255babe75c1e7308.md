# ALLAMMELECH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 978baaec745ff68d68017f734bcd898e0d22b7a90ba21183631c99325993963c -->

a-lam'-e-lek ('allammelekh, "oak of a king"): A town in the tribe of Asher, the location of which is not known (Jos 19:26; the King James Version Alammelech).
