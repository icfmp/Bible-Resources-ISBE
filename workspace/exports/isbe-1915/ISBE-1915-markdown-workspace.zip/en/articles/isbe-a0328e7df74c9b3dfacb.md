# AMARNA, TELL EL-

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 37092a98fffeaad54424196485d30b05b95de3d1f9e11a9936c0c52f775ca965 -->

tel-el-a-mar'-na. See TELL EL-AMARNA.
