# ABEL (1)

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 67ca9dc547f3571f643ca0fa6aa3b49705c676e03a929af21bb5e9762306a88b -->

a'-bel (hebhel; Abel; Westcott and Hort, The New Testament in Greek Habel; etymology uncertain. Some translation "a breath," "vapor," "transitoriness," which are suggestive of his brief existence and tragic end; others take it to be a variant of Jabal, yabhal, "shepherd" or "herdman," Ge 4:20. Compare Assyrian ablu and Babylonian abil, "son"): The second son of Adam and Eve. The absence of the verb harah (Ge 4:2; compare Ge 4:1) has been taken to imply, perhaps truly, that Cain and Abel were twins.

1. A Shepherd:

"Abel was a keeper of sheep, but Cain was a tiller of the ground," thus representing the two fundamental pursuits of civilized life, the two earliest subdivisions of the human race. On the Hebrew tradition of the superiority of the pastoral over agricultural and city life, see The Expositor T, V, 351 ff. The narrative may possibly bear witness to the primitive idea that pastoral life was more pleasing to Yahweh than husbandry.

2. A Worshipper:

"In process of time," the two brothers came in a solemn manner to sacrifice unto Yahweh, in order to express their gratitude to Him whose tenants they were in the land (Ge 4:3,4. See SACRIFICE).

How Yahweh signified His acceptance of the one offering and rejection of the other, we are not told. That it was due to the difference in the material of the sacrifice or in their manner of offering was probably the belief among the early Israelites, who regarded animal offerings as superior to cereal offerings. Both kinds, however, were fully in accord with Hebrew law and custom. It has been suggested that the Septuagint rendering of Ge 4:7 makes Cain's offense a ritual one, the offering not being "correctly" made or rightly divided, and hence rejected as irregular. "If thou makest a proper offering, but dost not cut in pieces rightly, art thou not in fault? Be still!" The Septuagint evidently took the rebuke to turn upon Cain's neglect to prepare his offering according to strict ceremonial requirements. dieles (Septuagint in the place cited.), however, implies nathach (nattach), and would only apply to animal sacrifices. Compare Ex 29:17; Le 8:20; Jud 19:29; 1Ki 18:23; and see COUCH.

3. A Righteous Man:

The true reason for the Divine preference is doubtless to be found in the disposition of the brothers (see CAIN). Well-doing consisted not in the outward offering (Ge 4:7) but in the right state of mind and feeling. The acceptability depends on the inner motives and moral characters of the offerers. "By faith Abel offered unto God a more excellent (abundant, pleiona) sacrifice than Cain" (Heb 11:4). The "more abundant sacrifice," Westcott thinks, "suggests the deeper gratitude of Abel, and shows a fuller sense of the claims of God" to the best. Cain's "works (the collective expression of his inner life) were evil, and his brother's righteous" (1Joh 3:12). "It would be an outrage if the gods looked to gifts and sacrifices and not to the soul" (Alcibiades II.149E.150A). Cain's heart was no longer pure; it had a criminal propensity, springing from envy and jealousy, which rendered both his offering and person unacceptable. His evil works and hatred of his brother culminated in the act of murder, specifically evoked by the opposite character of Abel's works and the acceptance of his offering. The evil man cannot endure the sight of goodness in another.

4. A Martyr:

Abel ranks as the first martyr (Mt 23:35), whose blood cried for vengeance (Ge 4:10; compare Re 6:9,10) and brought despair (Ge 4:13), whereas that of Jesus appeals to God for forgiveness and speaks peace (Heb 12:24) and is preferred before Abel's.

5. A Type:

The first two brothers in history stand as the types and representatives of the two main and enduring divisions of mankind, and bear witness to the absolute antithesis and eternal enmity between good and evil.

M. O. Evans
