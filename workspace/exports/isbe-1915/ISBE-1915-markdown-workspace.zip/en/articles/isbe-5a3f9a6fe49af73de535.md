# ABIHUD

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 3df7c0b8ca4ddc7fa84dcbcfe9c25bd818a0587168d6cee36b775c10a52bc87c -->

a-bi'-hud ('abhihudh, "father of majesty," or "my father is majesty," though some regard the second part as the proper name Judah): The son of Bela the oldest son of Benjamin (1Ch 8:3).
