# AFFIRM; AFFIRMATIVES

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 4612023c82cbdee31bdec1df567aa3e95d6dd1a725cf7a7ca499d584205abe60 -->

a-fur'-ma-tivs (diischurizomai). The verb "affirm" occurs in several passages of the New Testament in the sense of "assert" Lu 22:59; Ac 12:15; 25:19 pha-sko; Ro 3:8 phemi; 1Ti 17, Titus 3:8 diabebaioomai. The Hebrew does not employ affirmative particles, but gives a positive reply by either repeating the word in question or by substituting the first person in the reply for the second person in the question, or by employing the formula: "Thou hast said" or "Thou hast rightly said." The Saviour used this idiom (su eipas) when answering Judas and Caiaphas (Mt 26:25,64). A peculiar elegance occasionally attaches to the interpretation of the Scriptures because of their use of an affirmative and a negative together, rendering the sense more emphatic; sometimes the negative occurs first, as in Ps 118:17: "I shall not die, but live"; sometimes the affirmative precedes, as in Isa 88:1: "Thou shalt die, and not bye" Joh 1:20 is made peculiarly emphatic because of the negative placed between two affirmatives: "And he confessed, and denied not; and he confessed, I am not the Christ."

Frank E. Hirsch
