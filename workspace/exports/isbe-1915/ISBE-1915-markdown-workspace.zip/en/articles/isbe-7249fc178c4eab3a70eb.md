# ACHIM

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: e53fae344bcd15918e4de470ef1f93eaec653be4f738f8d0dd96a0e36508073a -->

a'-kim (Acheim): A descendant of Zerubbabel and ancestor of Jesus, mentioned only in Mt 1:14.
