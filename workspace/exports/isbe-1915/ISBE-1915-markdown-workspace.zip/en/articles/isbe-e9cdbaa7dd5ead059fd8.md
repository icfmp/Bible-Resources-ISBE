# ABRAHAM'S BOSOM

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 18eee34fa5930b462d530e8c44e9460bf3be0d122c8d44ca57038da99c939532 -->

booz'-um (kolpos Abraam; kolpoi Abraam): Figurative. The expression occurs in Lu 16:22,23, in the parable of the Rich Man and Lazarus, to denote the place of repose to which Lazarus was carried after his death. The figure is suggested by the practice of the guest at a feast reclining on the breast of his neighbor. Thus, John leaned on the breast of Jesus at supper (Joh 21:20). The rabbis divided the state after death (Sheol) into a place for the righteous and a place for the wicked (see ESCHATOLOGY OF THE OLD TESTAMENT; SHEOL); but it is doubtful whether the figure of Jesus quite corresponds with this idea. "Abraham's bosom" is not spoken of as in "Hades," but rather as distinguished from it (Lu 16:23)--a place of blessedness by itself. There Abraham receives, as at a feast, the truly faithful, and admits them to closest intimacy. It may be regarded as equivalent to the "Paradise" of Lu 23:43. See HADES; PARADISE.

James Orr
