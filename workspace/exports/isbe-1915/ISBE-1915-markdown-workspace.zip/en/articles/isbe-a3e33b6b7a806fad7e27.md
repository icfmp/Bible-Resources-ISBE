# ADDI

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 515a1b546275074545779b3023e7d5a4f8bcc6afa00963211e41e8b969566243 -->

ad'-i (Addi; Addei): An ancestor of Joseph, the husband of Mary, mother of Jesus; fourth from Zerubbabel in the ascending genealogical series (Lu 3:28).
