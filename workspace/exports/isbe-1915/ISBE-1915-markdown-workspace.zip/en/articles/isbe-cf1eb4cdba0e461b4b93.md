# AMRAPHEL

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 9891e8019f52f75c3370433fccad69e290d92c28732770dff9178cdfdf211d96 -->

am'-ra-fel, am-ra'-fel ('amraphel, or, perhaps better, 'ameraphel).

1. The Expedition Against Sodom and Gomorrah:

This name, which is identified with that of the renowned Babylonian king Hammurabi (which see), is only found in Ge 14:1,9, where he is mentioned as the king of Shinar (Babylonia), who fought against the cities of the plain, in alliance with Arioch king of Ellasar, Chedorlaomer king of Elam, and Tidal king of Nations (the Revised Version (British and American) GOIIM). The narrative which follows is very circumstantial. From it we learn, that Bera king of Sodom, Birsha king of Gomorrah, Shinab king of Admah, Shemeber king of Zeboiim, and the king of Bela or Zoar, had served Chedorlaomer for 12 years, rebelled in the 13th, and in the 14th year Chedorlaomer, with the kings enumerated, fought with and defeated them in the vale of Siddim, which is described as being the Salt Sea. Previous to this engagement, however, the Elamites and their allies had attacked the Rephaim (Onkelos: "giants") in Ashtaroth-karnaim, the Zuzim (O: "mighty ones," "heroes") in Ham (O: Chamta'), the Emim (O: "terrible ones") in Shaveh-kiriathaim, and the Horites in their Mount Seir, by the Desert. These having been rendered powerless to aid the revolted vassals, they returned and came to Enmishpat, or Kadesh, attacked the country of the Amalekites, and the Amorites dwelling in Hazazontamar (Ge 14:2-7).

2. The Preparation and the Attack:

At this juncture the kings of the cities of the plain came out against them, and opposed them with their battle-array in the vale of Siddim. The result of the fight was, that the kings of Sodom and Gomorrah, with their allies, fled, and fell among the bitumen-pits of which the place was full, whilst those who got away took refuge in the mountain. All the goods and food (the camp-equipment and supplies) of the kings of the plain were captured by Chedorlaomer and his allies, who then continued their march (to their own lands) (Ge 14:8-11).

3. Abraham's Rescue of Lot:

Among the captives, however, was Lot, Abram's nephew, who dwelt in Sodom. A fugitive, having escaped, went and announced the result of the engagement to Abram, who was at that time living by Mamre's oak plantation. The patriarch immediately marched forth with his trained men, and pursued them to Dan, where he divided his forces, attacked the Elamite-Babylonian army by night, and having put them to flight, pursued them again to Hobah, on the left (or North) of Damascus. The result of this sudden onslaught was that he rescued Lot, with the women and people, and recaptured Lot's goods, which the allies of Amraphel had carried off (Ge 14:12-16).

4. Difficulties of the Identification of Amraphel:

There is no doubt that the identification of Amraphel with the Hammurabi of the Babylonian inscriptions is the best that has yet been proposed, and though there are certain difficulties therein, these may turn out to be apparent rather than real, when we know more of Babylonian history. The "l" at the end of Amraphel (which has also "ph" instead of "p" or "b") as well as the fact that the expedition itself has not yet been recognized among the campaigns of Hammurabi, must be acknowledged as two points hard to explain, though they may ultimately be solved by further research.

5. Historical Agreements:

It is noteworthy, however, that in the first verse of Ge 14 Amraphel is mentioned first, which, if he be really the Babylonian Hammurabi, is easily comprehensible, for his renown to all appearance exceeded that of Chedorlaomer, his suzerain. In 14:4 and 5, however, it is Chedorlaomer alone who is referred to, and he heads the list of eastern kings in verse 9, where Tidal comes next (a quite natural order, if Goiim be the Babylonian Gute, i.e. the Medes). Next in order comes Amraphel, king of Babylonia and suzerain of Arioch of Ellasar (Eri-Aku of Larsa), whose name closes the list. It may also be suggested, that Amraphel led a Babylonian force against Sodom, as the ally of Chedorlaomer, before he became king, and was simply crown prince. In that case, like Belshazzar, he was called "king" by anticipation. For further details see ARIOCH and CHEDORLAOMER, and compare ERI-AKU and HAMMURABI; for the history of Babylonia during Hammurabi's period, see that article.

T. G. Pinches
