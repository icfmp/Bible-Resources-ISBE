# AGONY

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: acb8f340486375e6a64405cd3d5b839c78d6f077884c22be9b0dd00e79740c01 -->

ag'-o-ni (agonia; Vulgate agonia):

A word occurring only once in the New Testament (Lu 22:44), and used to describe the climax of the mysterious soul-conflict and unspeakable suffering of our Lord in the garden at Gethsemane. The term is derived from the Greek agon "contest" and this in turn from the Greek ago "to drive or lead," as in a chariot race. Its root idea is the struggle and pain of the severest athletic contest or conflict. The wrestling of the athlete has its counterpart in the wrestling of the suffering soul of the Saviour in the garden. At the beginning of this struggle He speaks of His soul being exceeding sorrowful even unto death, and this tumult of emotion culminated in the agony. All that can be suggested by the exhausting struggles and sufferings of charioteers, runners, wrestlers and gladiators, in Grecian and Roman amphitheaters, is summed up in the pain and death-struggle of this solitary word "agony." The word was rendered by Wyclif (1382) "maad in agonye" Tyndale (1534) and following translators use an agony." The record of Jesus' suffering in Gethsemane, in the Synoptic Gospels (Mt 26:36-46; Mr 14:32-42; Lu 22:39-46, and also in He 5:7,8) indicates that it was threefold:

1. Physical:

The agony of His soul wrought its pain on His body, until "his sweat became as it were great drops of blood falling down upon the ground" (Lu 22:44, omitted by some ancient authorities). He offered His prayers and supplications "with strong crying and tears" (He 5:7). The intensity of His struggle so distressed and weakened Him that Luke says "there appeared unto him an angel from heaven, strengthening him." The threefold record of the evangelists conveys the idea of the intensest physical pain. As the wire carries the electric current, so every nerve in Jesus' physical being felt the anguish of His sensitive soul as He took upon Himself the burden of the world's sin and moral evil.

2. Mental:

The crisis of Jesus' career as Messiah and Redeemer came in Gethsemane. The moral issue of His atoning work was intelligently and voluntarily met here. The Gospels exhaust language in attempting to portray the stress and struggle of this conflict. "My soul is exceeding sorrowful even unto death." "Being in an agony he prayed more earnestly, saying, Father, if it be possible, let this cup pass away from me." The mental clearness of Christ's vision of humanity's moral guilt and the energy of will necessary to meet the issue and take "this cup" of being the world's sin- bearer, indicate the awful sorrow and anguish of His supernatural conflict. It is divinely significant that the word "agony" appears but once in all Scripture. This solitary word records a solitary experience. Only One ever compassed the whole range of the world's sorrow and pain, anguish and agony. The shame of criminal arrest in the garden and of subsequent condemnation and death as a malefactor had to His innocent soul the horror of humanity's entire and ageless guilt. The mental and moral anguish of Jesus in Gethsemane interprets the meaning of Paul's description of the atonement, "Him who knew no sin he made to be sin on our behalf" (2Co 5:21).

3. Spiritual:

The agony of Jesus was supremely within the realm of His spirit. The effect of sin in separating the human soul from God was fathomed by the suffering Saviour in the fathomless mystery of His supernatural sorrow. Undoubtedly the anguish of Gethsemane surpassed the physical torture of Calvary. The whole conflict was wrought out here. Jesus' filial spirit, under the burden of the world's guilt, felt isolated from the Father. This awful, momentary seclusion from His Father's face constituted the "cup" which He prayed might pass from Him, and the "agony" of soul, experienced again on the cross, when He felt that God had forsaken Him.

No theory of the atonement can do justice to the threefold anguish of Jesus in Gethsemane and on Calvary, or to the entire trend of Scripture, that does not include the substitutionary element in His voluntary sacrifice, as stated by the prophet: "Yahweh hath laid on him the iniquity of us all," Isa 53:6; and by His apostles "who was delivered up for our trespasses," Ro 4:25; "who his own self bare our sins," 1Pe 2:24.

The word "agony" also occurs in 2 Macc 3:14,16,21 the King James Version (the Revised Version (British and American) "distress") in describing the distress of the people at the attempt of Heliodorus to despoil the treasury of the temple in the days of Onias.

Dwight M. Pratt
