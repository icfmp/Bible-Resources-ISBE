# ADIABENE

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: db94d25c02d00e5fd05d47000fdc467130a055c7c10100e582bbdbdaf289a716 -->

a-di-a-be'-ne (Adiabene): A state lying on the east of the Tigris, on the greater and lesser rivers Zab, in the territory of ancient Assyria. For the half-century terminating with the destruction of Jerusalem by Titus, Adiabene is especially interesting by reason of the careers of its king, Izates, and his mother Helena, who became Jews. They had their part in the Jewish-Roman wars, and in various ways were typical of the existing situation. (See Ant, XX, 2-5; BJ, II, xvi, 4; xix. 2; V, iv, 2; vi. 1; xi. 5; VI, vi, 4.) Somewhat later Adiabene was absorbed into the Roman Empire and became one of the six provinces which formed the larger province of Assyria, though Pliny and Ammianus sometimes call the large province by the name Adiabene.

Willis J. Beecher
