# ABDON (2)

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 764d2868c9d8fa8cd2c41446fe16354d4279be9c7aefe718547d94e9c20aff23 -->

ab'-don (`abhdon, perhaps "service"): One of the four Levitical cities in the tribe of Asher (Jos 21:30; 1Ch 6:74). Probably the same with Ebron (in the King James Version "Hebron") in Jos 19:28, where some copies have the reading Abdon. Now called Abdeh, a few miles from the Mediterranean and about fifteen miles south of Tyre.
