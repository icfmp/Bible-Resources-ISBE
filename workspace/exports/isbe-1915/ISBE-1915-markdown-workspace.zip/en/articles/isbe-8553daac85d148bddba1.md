# AMAZIAH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: f5f9ba753272d4df5ec02fa3565d1a4b06fc79b2aeb1ae8ee0ab64e09fe79d59 -->

am-a-zi'-a ('amatsyah, 'amatsyahu, "Yahweh is mighty"; 2Ki 14:1-20; 2Ch 25). Son of Jehoash, and tenth king of Judah. Amaziah had a peaceable accession at the age of 25. A depleted treasury, a despoiled palace and temple, and a discouraged people were among the consequences of his father's war with Hazael, king of Syria. When settled on the throne, Amaziah brought to justice the men who had assassinated his father. Amaziah verbal citation of De 24:16 in 2Ki 14:6, forbidding the punishment of children for a father's offense, shows that the laws of this book were then known, and were recognized as authoritative, and, in theory, as governing the nation. His accession may be dated circa 812 (some put later).

1. The Edomite War:

The young king's plan for the rehabilitation of his people was the restoration of the kingdom's military prestige, so severely lowered in his father's reign. A militia army, composed of all the young men above 20 years of age, was first organized and placed upon a war footing (2Ch 25:5; the number given, 300,000, is not a reliable one). Even this not being considered a large enough force to effect the project, 100 talents of silver were sent to engage mercenary troops for the expedition from Israel. When these came, a man of God strongly dissuaded the king from relying on them (2Ch 25:7 ff). When this was communicated to the soldiers, and they were sent back unemployed, it roused them to "fierce anger" (2Ch 25:10).

2. Its Occasion:

Amaziah's purpose in making these extensive preparations for war, in a time of profound peace, is clear to the Southeast of Judah lay the Edomite state, with its capital at Petra. For many years Edom had been subject to Jehoshaphat, and a Hebrew "deputy" had governed it (1Ki 22:47). In the reign of his son and successor, Jehoram, a confederacy of Philistines, Arabians and Edomites took Libnah and made a raid on Jerusalem. A band of these penetrated the palace, which they plundered, abducted some women, and murdered all the young princes but the youngest (2Ch 21:17; 22:1). The public commotion and distress caused by such an event may be seen reflected in the short oracle of the prophet Obadiah, uttered against Edom, if, with some, Obadiah's date is put thus early

3. The Victory in the Valley of Salt:

From that time "Edom .... made a king over themselves" (2Ch 21:8), and for fifty years following were practically independent. It was this blot on Jerusalem and the good name of Judah that Amaziah determined to wipe out. The army of retaliation went forward, and after a battle in the Valley of Salt, south of the Dead Sea, in which they were the victors, moved on to Petra. This city lies in a hollow, shut in by mountains, and approached only by a narrow ravine, through which a stream of water flows. Amaziah took it "by storm" (such is Ewald's rendering of "by war," in 2Ki 14:7). Great execution was done, many of the captives being thrown from the rock, the face of which is now covered with rock-cut tombs of the Greek-Roman age.

4. Apostasy and Its Punishment:

The campaign was thus entirely successful, but had evil results. Flushed with victory, Amaziah brought back the gods of Edom, and paid them worship. For this act of apostasy, he was warned of approaching destruction (2Ch 25:14-17). Disquieting news soon came relating to the conduct of the troops sent back to Samaria. From Beth-horon in the south to the border of the northern state they had looted the villages and killed some of the country people who had attempted to defend their property (2Ch 25:13). To Amaziah's demand for reparation, Jehoash's answer was the contemptuous one of the well-known parable of the Thistle and the Cedar.

5. Battle of Beth-shemesh:

War was now inevitable. The kings "looked one another in the face," in the valley of Beth-shemesh, where there is a level space, suitable to the movements of infantry. Judah was utterly routed, and the king himself taken prisoner. There being no treasures in the lately despoiled capital, Jehoash contented himself with taking hostages for future good behavior, and with breaking down 400 cubits of the wall of Jerusalem at the Northwest corner of the defense (2Ki 14:13,14; 2Ch 25:22-24).

6. Closing Years and Tragical End:

Amaziah's career as a soldier was now closed. He outlived Jehoash of Israel "fifteen years" (2Ki 14:17). His later years were spent in seclusion and dread, and had a tragical ending. The reason for his unpopularity is not far to seek. The responsibility for the war with Jehoash is by the inspired writer placed upon the shoulders of Amaziah (2Ki 14:9-11). It was he who "would not hear." The quarrel between the kings was one which it was not beyond the power of diplomacy to remedy, but no brotherly attempt to heal the breach was made by either king. When the results of the war appeared, it could not be but that the author of the war should be called upon to answer for them. So deep was his disgrace and so profound the sense of national humiliation, that a party in the state determined on Amaziah's removal, so soon as there was another to take his place. The age of majority among the Hebrew kings was 16, and when Amaziah's son was of this age, the conspiracy against his life grew so strong and open that he fled to Lachish. Here he was followed and killed; his body being insultingly carried to Jerusalem on horses, and not conveyed in a litter or coffin (2Ki 14:19,20; 2Ch 25:27,28). He was 54 years old and had reigned for 29 years. The Chronicler (2Ch 26:1) hardly conceals the popular rejoicings at the exchange of sovereigns, when Uzziah became king.

In 2Ch 25:28 is a copyist's error by which we read "in the city of Judah," instead of "in the city of David," as in the corresponding passage in Kings. The singular postscript to the record of Amaziah in 2Ki 14:22 is intended to mark the fact that while the port of Elath on the Red Sea fell before the arms, in turn, of Amaziah and of his son Uzziah, it was the latter who restored it to Judah, as a part of its territory. Amaziah is mentioned in the royal genealogy of 1Ch 3:12, but not in that of Mt 1. There is a leap here from Jehoram to Uzziah, Ahaziah, Jehoash and Amaziah being omitted.

W. Shaw Caldecott
