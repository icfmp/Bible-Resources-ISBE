# AHZAI

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: b4a066381c90e4755d790ace904eea57aece62442aafcf78db7eade15956007b -->

a'-zi ('achzay, "my protector"): A priest who resided in Jerusalem (Ne 11:13). The the King James Version has Ahasai which is probably the same as Jahzevah of 1Ch 9:12.
