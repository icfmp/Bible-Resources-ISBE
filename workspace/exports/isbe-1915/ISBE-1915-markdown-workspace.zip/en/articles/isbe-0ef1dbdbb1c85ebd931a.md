# ADONI-ZEDEK

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: df9af27ccd0dd5309f4e0d3ae7a778f61ff25d634538333a4a7d7835a157be2d -->

a-do-ni-ze'-dek ('adhonitsedheq, "lord of righteousness"): King of Jerusalem at the time of the conquest of Canaan (Jos 10:1). When he heard of the fall of Ai and the submission of the Gibeonites, he entered into a league with four other kings to resist Joshua and Israel, and to punish Gibeon (Jos 10:3,4), but was overthrown by Joshua in a memorable battle (Jos 10:12-14). Adoni-zedek and his four allies were shut up in a cave, while the battle lasted, and afterward were taken out by Joshua's order, put to death and hanged on trees (Jos 10:22-27). It is noticeable that the name is almost the equivalent of Melchizedek, malkitsedheq, "king of righteousness," who was ruler of Jerusalem in the time of Abraham.

Edward Mack
