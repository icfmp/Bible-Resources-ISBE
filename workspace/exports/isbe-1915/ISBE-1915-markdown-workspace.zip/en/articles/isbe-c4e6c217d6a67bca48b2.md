# AMPLIATUS

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: fff592abc03ce78eaa2a6d416b0e399fa3de9c345e1573401d0ba7de5260ddc4 -->

am-pli-a'-tus (Ampliatos, Codex Sinaiticus, A,B,F, Ampliatus; Amplias, D,E,L,P, the Revised Version (British and American) form; the King James Version Amplias): The name of a member of the Christian community at Rome, to whom Paul sent greetings (Ro 16:8). He is designated "my beloved in the Lord." It is a common name and is found in inscriptions connected with the imperial household. The name is found twice in the cemetery of Domitilla. The earlier inscription is over a cell which belongs to the end of the 1st century or the beginning of the 2nd century. The bearer of this name was probably a member of her household and conspicuous in the early Christian church in Rome.
