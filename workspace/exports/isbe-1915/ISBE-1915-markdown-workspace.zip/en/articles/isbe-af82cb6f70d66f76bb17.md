# ALCOVE

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 7b474cb350c7ce4ed86314e2433e99933cd205f8b5bc0c394fe4033e28acef64 -->

al'-kov (qubbah; the King James Version tent; the American Standard Revised Version pavilion; the American Revised Version, margin alcove): Perhaps a large tent occupied by a prince (Nu 25:8).
