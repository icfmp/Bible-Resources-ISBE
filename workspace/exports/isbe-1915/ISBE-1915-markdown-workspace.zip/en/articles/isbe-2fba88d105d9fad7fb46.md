# AHOLIBAMAH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 91d09d8b6478b8ea7ac0a881b315b47c2e0f2d550c46161a246753da846085f1 -->

a-ho-li-ba'-ma. See OHOLIBAMAH.
