# ALONG

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 0115085b29e5b8d5c3835552a7e2a00b8098e22c4012f719b1f55ff060bbd01f -->

a-long': Corresponding to two different Hebrew words, Jud 9:25; 1Sa 6:12; Jer 41:6, joined with "come" and "go," vividly describes a course that is taken--it emphasizes its directness and immediateness. In Jud 7:12, "lay along in the valley," probably means "all the length" or "at length."
