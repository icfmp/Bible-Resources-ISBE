# AHAZ

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 1ae88ac7a8ab1944b713a287764e5e7ff47000812d0e01fdaedf7f469e060695 -->

a'-haz ('achaz, "he has grasped," 2Ki 16; 2Ch 28; Isa 7:10 ff; Achaz).

1. Name:

The name is the same as Jehoahaz; hence appears on Tiglath-pileser's Assyrian inscription of 732 BC as Ia-u-ha-zi. The sacred historians may have dropped the first part of the name in consequence of the character of the king.

2. The Accession:

Ahaz was the son of Jotham, king of Judah. He succeeded to the throne at the age of 20 years (according to another reading 25). The chronology of his reign is difficult, as his son Hezekiah is stated to have been 25 years of age when he began to reign 16 years after (2Ki 18:2). If the accession of Ahaz be placed as early as 743 BC, his grandfather Uzziah, long unable to perform the functions of his office on account of his leprosy (2Ch 26:21), must still have been alive. (Others date Ahaz later, when Uzziah, for whom Jotham had acted as regent, was already dead.)

3. Early Idolatries:

Although so young, Ahaz seems at once to have struck out an independent course wholly opposed to the religious traditions of his nation. His first steps in this direction were the causing to be made and circulated of molten images of the Baalim, and the revival in the valley of Hinnom, south of the city, of the abominations of the worship of Moloch (2Ch 28:2,3). He is declared to have made his own son "pass through the fire" (2Ki 16:3); the chronicler puts it even more strongly: he "burnt his children in the fire" (2Ch 28:3). Other acts of idolatry were to follow.

4. Peril from Syria and Israel:

The kingdom of Judah was at this time in serious peril. Rezin, king of Damascus, and Pekah, king of Samaria, had already, in the days of Jotham, begun to harass Judah (2Ki 15:37); now a conspiracy was formed to dethrone the young Ahaz, and set upon the throne a certain "son of Tabeel" (Isa 7:6). An advance of the two kings was made against Jerusalem, although without success (2Ki 16:5; Isa 7:1); the Jews were expelled from Elath (2Ki 16:6), and the country was ravaged, and large numbers taken captive (2Ch 28:5 ff). Consternation was universal. The heart of Ahaz "trembled, and the heart of his people, as the trees of the forest tremble with the wind" (Isa 7:2). In his extremity Ahaz appealed to the king of Assyria for help (2Ki 16:7; 2Ch 28:16).

5. Isaiah's Messages to the King:

Amid the general alarm and perturbation, the one man untouched by it in Jerusalem was the prophet Isaiah. Undismayed, Isaiah set himself, apparently single-handed, to turn the tide of public opinion from the channel in which it was running, the seeking of aid from Assyria. His appeal was to both king and people. By Divine direction, meeting Ahaz "at the end of the conduit of the upper pool, in the highway of the fuller's field," he bade him have no fear of "these two tails of smoking firebrands," Rezin and Pekah, for, like dying torches, they would speedily be extinguished (Isa 7:3 ff). If he would not believe this he would not be established (Isa 7:9). Failing to win the young king's confidence, Isaiah was sent a second time, with the offer from Yahweh of any sign Ahaz chose to ask, "either in the depth, or in the height above," in attestation of the truth of the Divine word. The frivolous monarch refused the arbitrament on the hypocritical ground, "I will not ask, neither will I tempt Yahweh" (Isa 7:10-12). Possibly his ambassadors were already dispatched to the Assyrian king. Whenever they went, they took with them a large subsidy with which to buy that ruler's favor (2Ki 16:8). It was on this occasion that Isaiah, in reply to Ahaz, gave the reassuring prophecy of Immanuel (Isa 7:13 ff).

6. Isaiah's Tablet:

As respects the people, Isaiah was directed to exhibit on "a great tablet" the words "For Maher-shalal-hash-baz" ("swift the spoil, speedy the prey"). This was attested by two witnesses, one of whom was Urijah, the high priest. It was a solemn testimony that, without any action on the part of Judah, "the riches of Damascus and the spoil of Samaria shall be carried away before the king of Assyria" (Isa 8:1-4).

7. Fall of Damascus and Its Results:

It was as the prophet had foretold. Damascus fell, Rezin was killed (2Ki 16:9), and Israel was raided (2Ki 15:29). The action brought temporary relief to Judah, but had the effect of placing her under the heel of Assyria. Everyone then living knew that there could be no equal alliance between Judah and Assyria, and that the request for help, accompanied by the message, "I am thy servant" (2Ki 16:7,8) and by "presents" of gold and silver, meant the submission of Judah and the annual payment of a heavy tribute. Had Isaiah's counsel been followed, Tiglath-pileser would probably, in his own interests, have been compelled to crush the coalition, and Judah would have retained her freedom.

8. Sun-Dial of Ahaz:

The political storm having blown over for the present, with the final loss of the important port of Elath on the Red Sea (2Ki 16:6), Ahaz turned his attention to more congenial pursuits. The king was somewhat of a dilettante in matters of art, and he set up a sun-dial, which seems to have consisted of a series of steps arranged round a short pillar, the time being indicated by the position of the shadow on the steps (compare 2Ki 20:9-11; Isa 38:8). As it is regarded as possible for the shadow to return 10 steps, it is clear that each step did not mark an hour of the day, but some smaller period.

9. The Lavers and Brazen Sea:

Another act of the king was to remove from the elaborate ornamental bases on which they had stood (compare 1Ki 7:27-39), the ten layers of Solomon, and also to remove Solomon's molten sea from the 12 brazen bulls which supported it (compare 1Ki 7:23-26), the sea being placed upon a raised platform or pavement (2Ki 16:17). From Jer 52:20, where the prophet sees "the 12 brazen bulls that were under the bases," it has been conjectured that the object of the change may have been to transfer the layers to the backs of the bulls.

10. The Damascus Altar:

To this was added a yet more daring act of impiety. In 732 Ahaz was, with other vassal princes, summoned to Damascus to pay homage to Tiglath-pileser (2Ki 16:10; his name appears in the Assyrian inscription). There he saw a heathen altar of fanciful pattern, which greatly pleased him. A model of this was sent to Urijah the high priest, with instructions to have an enlarged copy of it placed in the temple court. On the king's return to Jerusalem, he sacrificed at the new altar, but, not satisfied with its position, gave orders for a change. The altar had apparently been placed on the east side of the old altar; directions were now given for the brazen altar to be moved to the north, and the Damascus altar to be placed in line with it, in front of the temple giving both equal honor. Orders were further given to Urijah that the customary sacrifices should be offered on the new altar, now called "the great altar," while the king reserved the brazen altar for himself "to inquire by" (2Ki 16:15).

11. Further Impieties:

Even this did not exhaust the royal innovations. We learn from a later notice that the doors of the temple porch were shut, that the golden candlestick was not lighted, that the offering of incense was not made, and other solemnities were suspended (2Ch 29:7). It is not improbable that it was Ahaz who set up `the horses of the sun' mentioned in 2Ki 23:11, and gave them accommodation in the precincts of the temple. He certainly built the "altars .... on the roof of the upper chamber of Ahaz," perhaps above the porch of the temple, for the adoration of the heavenly bodies (verse 12). Many other idolatries and acts of national apostasy are related regarding him (2Ch 28:22 ff).

12. Recurrence of Hostilities:

In the later years of his unhappy reign there was a recurrence of hostilities with the inhabitants of Philistia and Edom, this time with disaster to Judah (see the list of places lost in 2Ch 28:18,19). New appeal was made to Tiglath-pileser, whose subject Ahaz, now was, and costly presents were sent from the temple, the royal palace, and even the houses of the princes of Judah, but without avail (2Ch 28:19-21). The Assyrian `distressed' Ahaz, but rendered no assistance. In his trouble the wicked king only "trespassed yet more" (2Ch 28:22).

13. Death of Ahaz:

Ahaz died in 728, after 16 years of misused power. The exultation with which the event was regarded is reflected in Isaiah's little prophecy written "in the year that King Ahaz died" (Isa 14:28-32). The statement in 2Ki 16:20 that Ahaz "was buried with his fathers in the city of David" is to be understood in the light of 2Ch 28:27, that he was buried in Jerusalem, but that his body was not laid in the sepulchers of the kings of Israel. His name appears in the royal genealogies in 1Ch 3:13 and Mt 1:9.

W. Shaw Caldecott
