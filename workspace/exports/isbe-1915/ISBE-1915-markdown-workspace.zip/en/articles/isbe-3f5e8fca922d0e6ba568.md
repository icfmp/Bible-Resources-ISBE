# AGUR

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 0fc027c8ca9405f8a160b1a056ed9ed55caadfad867f9681fcff5c546e5ef3d1 -->

a'-gur ('aghur, seeming, from comparison with Arabic roots, to mean either "hireling," or "collector," "gatherer"): One of the contributors to Proverbs; his words being included in Pr 30. He takes an agnostic attitude toward God and transcendent things, and in general the range of his thought, as compared with that of other authors, is pedestrian. He shows, however, a tender reverence and awe. His most notable utterance, perhaps, is the celebrated Prayer of Agur (Pr 30:7-9), which gives expression to a charming golden mean of practical ideal. His sayings are constructed on a rather artificial plan; having the form of the so-called numerical proverb. See under PROVERBS, THE BOOK OF, II, 6.

John Franklin Genung
