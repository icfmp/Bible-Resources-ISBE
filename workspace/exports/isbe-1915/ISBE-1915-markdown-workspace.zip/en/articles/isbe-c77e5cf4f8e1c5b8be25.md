# ACCORD; ACCORDING; ACCORDINGLY

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: f33f870d7a4f56e564a73e9069383c9b88e78acdc59f7f2e4cd685c55ca91539 -->

a-kord', a-kord'-ing-li: In Old Testament, peh, "mouth," "to fight with one accord" (Jos 9:2) lephi, "according to the mouth of," "according to their families" (Ge 47:12, "acc. to (the number of) their little ones" the Revised Version, margin). In Isa 59:18 the same Hebrew word, ke`al, is rendered "according to" and "accordingly." In New Testament homothumadon, indicative of harmony of mind or action, Acts, 1:14, 2:46, 7:57, 18:12 and kata, of the same mind .... according to Christ Jesus (Ro 15:5); automatos, "of itself," "without constraint," "opened to them of its own accord" (Ac 12:10), i.e. without human agency (compare Le 25:5 the King James Version; Mr 4:28); authairetos, "of his own free choice" (2Co 8:17). God "will render to every man according to his works" (Ro 2:6), that is, agreeably to the nature of his works (1Co 3:8), but salvation is not according to works (2Ti 1:9; Titus 3:5).

See DEED.

M. O. Evans
