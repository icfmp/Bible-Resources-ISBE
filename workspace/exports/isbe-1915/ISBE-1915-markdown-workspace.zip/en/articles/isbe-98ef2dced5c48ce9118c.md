# AMBUSHMENT

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 7dc5b7ec2c2485360b78519459e4997d2a26846a18429d077d96402832caa6a4 -->

am'-boosh-ment (as above) has now disappeared in 2Ch 20:22, where the Revised Version (British and American) gives for "ambushment" "liers-in-wait." It still remains in 2Ch 13:13 where both the King James Version and the Revised Version (British and American) render the Hebrew noun "ambushment."
