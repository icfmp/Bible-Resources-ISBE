# ADINUS

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 060fcc96726292fa861607fdfad7a1cdb5c66f1514fa1234e950c92aa304098a -->

ad'-i-nus. See IADINUS (Apocrypha).
