# ALL

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: ccf23c761bce8e9f000ba1b8be4d2c0f2977f454259acde271195d7635e8cd4f -->

ol: Used in various combinations, and with different meanings.

(1) All along, "Weeping all along as he went" (Jer 41:6), i.e. throughout the whole way he went, feigning equal concern with the men from Shiloh, etc., for the destruction of the Temple, so as to put them off their guard.

(2) All in all, "That God may be all in all" (1Co 15:28, Greek: panta en pasin, "all things in all (persons and) things"). "The universe, with all it comprises, will wholly answer to God's will and reflect His mind" (Dummelow).

(3) All one, "It is all one" (Job 9:22), "it makes no difference whether I live or die."

(4) At all, "If thy father miss me at all" (1Sa 20:6), "in any way," "in the least."

(5) All to, "All to brake his skull" (Jud 9:53 the King James Version) an obsolete form signifying "altogether"; "broke his skull in pieces."

(6) Often used indefinitely of a large number or a great part, "All the cattle of Egypt died" (Ex 9:6; compare Ex 9:19,25); "all Judea, and all the region round about" (Mt 3:5); "that all the world should be enrolled" (Lu 2:1); "all Asia and the world" (Ac 19:27); "All (people) verily held John to be a prophet" (Mr 11:32).

M. O. Evans
