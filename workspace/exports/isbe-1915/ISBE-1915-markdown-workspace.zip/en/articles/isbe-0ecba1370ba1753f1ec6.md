# ADD

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: a4c4be7fa980425db3f3ca0b2dc4a6cfbbb2018851f243cecea16d5bef83d1a3 -->

(1) epidiatassomai, "to add to," "to arrange in addition": Found only in Ga 3:15, which may thus be paraphrased: "To take a familiar illustration: even a man's will, when ratified, no third party may annul or supplement" (Dummelow, in the place cited.).

(2) epitithemi, "to put upon," "If any man shall add unto them, God shall add unto him the plagues" (Re 22:18). The book is not to be falsified by addition or excision (see BOOK) by the interpolation of unauthorized doctrines or the neglect of essential ones (compare De 4:2; 12:32).

See also IMPART; SUPPLY.

M. O. Evans
