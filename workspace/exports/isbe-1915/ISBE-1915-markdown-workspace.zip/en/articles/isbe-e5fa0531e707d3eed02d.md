# ABROAD, SCATTERED

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: f347ccb9787f7fefab8112b0421faaa612f99d9bbc79f2f85b1c6afd4a62c025 -->

See DISPERSION.
