# AHIAH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: c1f4d4582b756385f43b0da57db70a99b776266ed4b27a99b376a1722da71784 -->

a-hi'-a: A variant in the King James Version (1Sa 14:3,18; 1Ki 4:3; 1Ch 8:7) for AHIJAH, which see. Also in the Revised Version (British and American) (Ne 10:26).
