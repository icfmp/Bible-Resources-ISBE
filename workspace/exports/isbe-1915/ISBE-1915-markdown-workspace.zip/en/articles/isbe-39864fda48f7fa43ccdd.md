# AKRABBIM

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: e4a2b575f8a4508289cca544ca841434c3335a66c20afcdf1520f482b7cbd61d -->

ak-rab'-im (once in the King James Version, Acrabbim (Jos 15:3); `aqrabbim, "scorpions"): Three times found (Nu 34:4; Jos 15:3; Jud 1:36), and always with ma`aleh, "ascent" or "pass"; and so "Ascent of the Scorpions," an ascent at the Southwest point of the Dead Sea and a part of the boundary line between Judah and Edom. At this pass Judas Maccabeus won a victory over the Edomites (1 Macc 5:3), called in the King James Version, Arabattine.
