# ABISHALOM

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 48a5ccc67e649321e0e49818685b858d8383a6c12bc881b0b69e6bbd40f802df -->

a-bish'-a-lom: Variant of ABSALOM, which see.
