# AIN (2)

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: c812773ae067af79784efc6dc034745312350720d32795e214205cd107cc328d -->

a'-in (`ayin, "eye or spring (of water)"):

(1) A town in the extreme Northwest corner of Canaan, so named, most probably, from a noted spring in the vicinity (Nu 34:11). Thomson and after him Robinson make Ain the same as `Ain el-`Asy, the chief source of the Orontes, some fifteen miles Southwest of Riblah, which, in turn, is about twenty miles Southwest of Emesa (Hums). As Ain is named in connection with Lake Gennesaret, some claim that Riblah of Nu 34:11 must be another place farther South and closer to that lake.

(2) A Levitical city (Jos 21:16) in the Negeb or southern part of Judah. It was first allotted to the tribe of Judah (Jos 15:32) but later to Simeon (Jos 19:7). The fact that it is several times named in immediate connection with Rimmon has lent plausibility to the view that we have here a compound word, and that we should read En-Rimmon, i.e. Ain-Rimmon (see Jos 15:32; 19:7; 1Ch 4:32). See also AYIN.

W. W. Davies
