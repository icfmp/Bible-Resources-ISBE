# AHUZZAM; AHUZAM

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: c64013f83e2ea1ae4d172e61e23f9f3d7dac4606cf6e3751b4f419f2d125d535 -->

a-huz'-am, a-hu'-zam ('achuzzam, "possessor"). A son of Ashahur of the tribe of Judah, his mother's name was Naarah (1Ch 4:6); written Ahuzam in the King James Version.
