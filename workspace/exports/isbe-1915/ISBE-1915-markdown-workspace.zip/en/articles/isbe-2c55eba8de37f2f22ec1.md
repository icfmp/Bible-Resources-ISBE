# ALLAR

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 89992ff68aedefda33579ddb6619cf07d3a4f78b109d91aedd5c740ec68474c8 -->

al'-ar (the King James Version, Aalar; Aalar): Occurring once (1 Esdras 5:36) and used apparently to indicate a place from which certain Jews came on the return from captivity, who could not prove their lineage, and were excluded for this reason from the privileges of the priesthood. HDB identifies with Immer of Ezr 2:59 and Ne 7:61 (which see), but this is not at all certain.
