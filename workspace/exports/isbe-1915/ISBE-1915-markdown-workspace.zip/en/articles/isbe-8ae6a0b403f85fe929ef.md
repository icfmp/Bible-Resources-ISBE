# AHIO

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: ed0f1d8a012210d343d4e2d9588688961653981555082ba8ea91ddaa7a60e922 -->

a-hi'-o ('achyo, variously explained as "his brother," "brotherly," "brother of Yahweh," "my brother is Yah"): Proper names containing a similar form of the name of Yahweh are found on the ostraca recently exhumed at Samaria. The word is always treated as a common noun in the ordinary Greek copies, being rendered either "brother" or "brothers," or "his brother" or "his brothers"; but this is probably to be taken as an instance of the relative inferiority of the Greek text as compared with the Massoretic Text. See OSTRACA.

(1) One of the sons of Beriah, the son of Elpaal, the son of Shaharaim and Hushim, reckoned among the families of Benjamin (1Ch 8:14). Beriah and Shema are described as `ancestral heads' "of the inhabitants of Aijalon, who put to flight the inhabitants of Gath."

(2) A descendant of Jeiel ("the father of Gibeon") and his wife Maacah (1Ch 8:31; 9:37). King Saul apparently came from the same family (1Ch 8:30,33; 9:39).

(3) One of the men who drove the new cart when David first attempted to bring the ark from the house of Abinadab to Jerusalem (2Sa 6:3,4; 1Ch 13:7). In Samuel Uzza and Ahio are called sons of Abinadab. By the most natural understanding of the Biblical data about 100 years had elapsed since the ark was brought to the house; they were sons of that Abinadab in the sense of being his descendants. Whether he had a successor of the same name living in David's time is a matter of conjecture.

Willis J. Beecher
