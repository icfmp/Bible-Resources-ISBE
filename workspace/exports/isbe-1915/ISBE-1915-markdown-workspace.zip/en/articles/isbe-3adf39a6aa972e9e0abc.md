# AMAIN

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 1399ee0cf892a4dd069e75f1b3f51f51ca408372878e55448cbb93d79e4b6edd -->

a-man' (translated from the Greek eis phugen hormesan, "they rushed to flight"): The word is composed of the prefix "a" and the word "main," meaning "force." The expression is used by Milton, Parker, et al., but in Biblical literature found only in 2 Macc 12:22 where used to describe the flight of Timotheus and his army after he suffered defeat at the hands of Judas Maccabee ("They fled amain," i.e. violently and suddenly).
