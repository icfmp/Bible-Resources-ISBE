# AHINADAB

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 7e45d124d7cf35949d783c84f37fb8be44368820b13380eab4cafe507c4f1e79 -->

a-hin'-a-dab ('achinadhabh, "brother of willingness," or, "my brother is willing"): Decidedly the ordinary use of the stem nadhabh is to denote willingness rather than liberality or nobleness One of Solomon's twelve commissary officers (1Ki 4:14). He was the son of Iddo, and his district was Mahanaim.
