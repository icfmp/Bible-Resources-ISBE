# ABDEEL

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 22006a9f116843d22f5fbb0294b84a43246fc14b9058e3b4f8899c8a3b6e1d72 -->

ab'-de-el (`abhdeel, "servant of God"): The father of Shelemiah, one of the officers whom King Jehoiakim commanded to arrest Baruch, the scribe, and Jeremiah the prophet (Jer 36:26).
