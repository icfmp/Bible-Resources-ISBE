# ALMIGHTY

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 9c6d9c281de0147e16ba9de77e6516c8dc2e0f5b4c3b9ea9fce15ffb98183d38 -->

ol-mit'-i:

(1) (shaddai (Ge 17:1)): Found in the Old Testament forty-eight times, most of these in the Book of Job; it occurs either alone or in combination with 'el, "God"). The root meaning is uncertain.

(2) (pantokrator), the exclusive translation of this Greek word in the New Testament, found principally in Re (nine times), once besides (2Co 6:18). Its occurrence in the Apocrypha is frequent. See GOD, NAMES OF.
