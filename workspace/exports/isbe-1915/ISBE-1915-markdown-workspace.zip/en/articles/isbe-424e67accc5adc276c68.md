# AGUE

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 6b39c4e9fd07ad7881763edb8aeb57e28bb232ccf9a7afec5abb2d74db9e2842 -->

a'-gu (qaddachath): In Le 26:16 the King James Version is one of the diseases threatened as a penalty for disobedience to the law. The malady is said to "consume the eyes, and make the soul to pine away." The word means burning (Vulgate "ardor") and was probably intended to denote the malarial fever so common now both in the Shephelah and in the Jordan valley. In Septuagint the word used (ikteros) means jaundice, which often accompanies this fever. the Revised Version (British and American) translates it "fever." See FEVER.
