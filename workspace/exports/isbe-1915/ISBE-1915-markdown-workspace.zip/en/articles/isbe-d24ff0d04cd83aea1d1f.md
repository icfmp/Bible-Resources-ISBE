# AMARIAH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 17b183d9f9db38642982e33f23d24a6a3ce4fa08f8ca80aa5054bb68e4be757a -->

am-a-ri'-a ('amaryah and 'amaryahu, "the Lord has said"; compare HPN, 180, 285).

(1) A Levite in the line of Aaron-Eleazar; a son of Meraioth and grandfather of Zadok (1Ch 6:7,52) who lived in David's time. Compare Zadok (2Sa 15:27, etc.) also Ant, VIII, i, 3 and X, viii, 6.

(2) A Levite in the line of Kohath-Hebron referred to in 1Ch 23:19 and 24:23 at the time when David divided the Levites into courses.

(3) A Levite in the line of Aaron-Eleazar; a son of Azariah who "executed the priest's office in the house that Solomon built" (1Ch 6:10 f). Compare Ezr 7:3 where in the abbreviated list this Amariah is mentioned as an ancestor of Ezra. See AMARIAS (1 Esdras 8:2; 2 Esdras 1:2) and number (4) of this article

(4) Chief priest and judge "in all matters of Yahweh" appointed by Jehoshaphat (2Ch 19:11). Possibly identical with Amariah, number (3).

(5) A descendant of Judah in the line of Perez and an ancestor of Ataiah who lived in Jerusalem after the Babylonian exile (Ne 11:4). Compare Imri (1Ch 9:4) and number (7) of this article, which Amariah seems to be of the same family,

(6) A Levite and an assistant of Kore who was appointed by Hezekiah to distributed the "oblations of Yahweh" to their brethren (2Ch 31:15).

(7) A son of Bani who had married a foreign woman (Ezr 10:42). See number (5) of this article

(8) A priest who with Nehemiah sealed the covenant (Ne 10:3); he had returned to Jerusalem with Zerubbabel (Ne 12:2) and was the father of Jehohanan (compare Hanani, Ezr 10:20), priest at the time of Joiakim (Ne 12:13). Compare Immer (Ezr 2:37; 10:20; Ne 7:40) and also Emmeruth (the King James Version "Meruth," 1 Esdras 5:24).

(9) An ancestor of Zephaniah, the prophet (Ze 1:1).

A. L. Breslich
