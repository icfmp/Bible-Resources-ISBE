# ADAH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 77027baa988a59cffa060109848a59e8deabdea254cb1e3fce37f0b0260225cc -->

a'-da (`adhah, "adornment"):

(1) One of the two wives of Lamech the descendant of Cain (Ge 4:19,20,23). The narrative in Ge assigns to her two sons, Jabal the "father" of tent-dwelling people, and Jubal the "father" of all such as handle the harp and pipe." Josephus says that Lamech had 77 sons by Ada and Zillah (Ant., I, ii, 2).

(2) According to Ge 36:2,4,10,12,16, the Hittite wife of Esau, daughter of Elon, and mother of Eliphaz. In this chapter Esau's other wives are Oholibamah, a Hivite, and Basemath the daughter of Ishmael. The names are differently given elsewhere (Ge 26:34; 28:9). Basemath is said to be the daughter of Elon. The daughter of Ishmael is called Mahalath. In place of Oholibamah the Hivite we find Judith the daughter of Beeri the Hittite. Data are lacking for the solution of the problem.

Willis J. Beecher
