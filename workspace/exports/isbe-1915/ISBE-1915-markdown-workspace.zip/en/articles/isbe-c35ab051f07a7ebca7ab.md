# ABIASAPH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 7b4b2614226a1e9964e275c3d8af1d5b5c51e0889e9bc51c9f0a5bcf71248273 -->

a-bi'-a-saf, ab-i-a'-saf ('abhi-'acaph, "my father has gathered"): A descendant of Kohath the son of Levi (Ex 6:24; 1Ch 6:23,37 (1Ch 8,22);1Ch 9:19). In Chronicles the name is 'ebh-yacaph, which seems to be a mere variant spelling. The Samaritan version has the same form in Exodus. The list in Exodus terminates with Abiasaph, who is to be regarded as the contemporary of Phinehas, the grandson of Aaron. The two lists in 1Ch 6 lead up to the prophet Samuel and the singing companies which David is said to have organized. The list in 1Ch 9 leads up to the Korahite porters of the time of Nehemiah. Apparently all the lists intentionally omit names, just names enough being given in each to indicate the line. Willis J. Beecher
