# AMATH; AMATHIS

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: a6fc5f93ae06896350ae518164b7ccc513f7e65a7948f74cb559d8305cd43e35 -->

a'-math, am'-a-this (1 Macc 12:25). See HAMATH.
