# ADYTUM

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 77093f4bca43a39d67b8b18d6df538443689ace56581a09e8615e3764d8e793b -->

ad'-i-tum (Latin from Greek aduton, adjective adutos, "not to be entered"): Applied to the innermost sanctuary or chambers in ancient temples, and to secret places which were open only to priests: hence, also to the Holy of Holies in the Jewish temple.

See TEMPLE.
