# AHOAH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 76975efa954c018828ec39f0d655efc14df47b11d1031a2059b43df61328f2be -->

a-ho'-a ('achoah, "brotherly"(?)): A son of Bela of the tribe of Benjamin (1Ch 8:4).
