# ADRIA

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 0d821b634d36a240309ebbbf52ccee0858d423701ae6837750ee31e3711e6603 -->

a'-dri-a (Westcott-Hort: ho Hadrias or ho Adrias): In Greek Adrias (Polybios i.2.4), Adriatike Thalassa (Strabo iv.204), and Adriatikon Pelagos (Ptolemy iii.15.2), and in Latin Adriaticum mare (Livy xl.57.7), Adrianum mare (Cicero in Pisonem 38), Adriaticus sinus (Livy x.2.4), and Mare superurn (Cicero ad Att. 9.5.1). The Adriatic Sea is a name derived from the old Etruscan city Atria, situated near the mouth of the Po (Livy v.33.7; Strabo v.214). At first the name Adria was only applied to the most northern part of the sea. But after the development of the Syracusan colonies on the Italian and Illyrian coasts the application of the term was gradually extended southward, so as to reach Mons Garganus (the Abruzzi), and later the Strait of Hydruntum (Ptolemy iii.1.1; Polybios vii.19.2). But finally the name embraced the Ionian Sea as well, and we find it employed to denote the Gulf of Tarentum (Servius Aen xi.540), the Sicilian Sea (Pausanias v. 25), and even the waters between Crete and Malta (Orosius i.2.90). Procopius considers Malta as lying at the western extremity of the Adriatic Sea (i.14). After leaving Crete the vessel in which the apostle Paul was sailing under military escort was "driven to and fro in the sea of Adria" fourteen days (Ac 27:27) before it approached the shore of Malta. We may compare this with the shipwreck of Josephus in "the middle of the Adria" where he was picked up by a ship sailing from Cyrene to Puteoli (Josephus, Vita, 3).

George H. Allen
