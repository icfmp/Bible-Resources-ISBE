# ABI-ALBON

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 8892f1866168b72ec1af1ad0bf45c9ce6809b155dfe7cc2eb8c5eaf323a8be0c -->

ab-i-al'-bon, abi-al'-bon ('abhi `alebhon, meaning not known. Gesenius infers from the Arabic a stem which would give the meaning "father of strength," and this is at worst not quite so groundless as the conjectures which explain `alebhon as a textual misreading for 'el or ba`al): Abi-albon the Arbathite was one of David's listed heroes (2Sa 23:31), called Abiel the Arbathite in 1Ch 11:32. Presumably he was from Beth- arabah (Jos 15:6,61, 18:22).
