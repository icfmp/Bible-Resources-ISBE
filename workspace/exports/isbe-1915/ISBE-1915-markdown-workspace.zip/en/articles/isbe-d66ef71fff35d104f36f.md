# AMITTAI

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 180a96d3bdd68ef683c100a5360197ee202ea123dc5a7d7caae25b19f2e0323a -->

a-mit'-i ('amittay, "faithful"): The father of the prophet Jonah. He was from Gath-hepher in Zebulun (2Ki 14:25; Jon 1:1).
