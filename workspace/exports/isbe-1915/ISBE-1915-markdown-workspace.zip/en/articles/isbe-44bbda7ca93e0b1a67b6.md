# AHIKAM

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 68cfeca6991d67ff3cc74611ffb810fa632c74ae6c735d885b9214350fffb880 -->

a-hi'-kam ('achiqam, "my brother has risen up"): A prominent man of the time of King Josiah and the following decades (2Ki 22:12,14; 25:22; 2Ch 34:20; Jer 26:24; 39:14; 40:5 ff; 41:1 ff; 43:6). He was the son of Shaphan, who very likely is to be identified with Shaphan the scribe, who was at that time so prominent. Ahikam was the father of Gedaliah, whom, on the capture of Jerusalem, Nebuchadnezzar made governor of the land. Ahikam was a member of the deputation sent by Josiah to the prophetess Huldah to consult her concerning the contents of the Book of the Law which had been found. Under Jehoiakim he had sufficient influence to protect Jeremiah from being put to death. On the capture of Jerusalem Nebuchadnezzar committed Jeremiah into the care of Gedaliah. It is clear that both Shaphan and his son, like Jeremiah, belonged to the party which held that the men of Judah were under obligation to keep the oath which they had sworn to the tang of Babylon.

Willis J. Beecher
