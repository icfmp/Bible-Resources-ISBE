# ALEMA

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 0541a4ba00298762ace0025c6a104e517aab4cc3a94bbba37e8e18053f3df561 -->

al'-e-ma (Alemois): A town in Gilead, mentioned once only (1 Macc 5:26), besieged by the nations under Timotheus, together with Bosor and other cities; and probably relieved along with these cities by Judas Maccabeus, although no mention is made of Alema's relief. The name occurs the one time as dative plural.
