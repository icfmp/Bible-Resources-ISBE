# ADAIAH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: f3586591dc19839cb1924168dbcc66c73bf33cbc6c43409cc87e3873c2920fe8 -->

a-da'-ya, a-di'-a (`adhayah, "Yahweh hath adorned"):

(1) Apparently the seventh of the nine sons of Shimei, who is apparently the same with Shema, who is the fifth of the sons of Elpaal, who is the second of the two sons of Shaharaim and Hushim (1Ch 8:21). Shaharaim and his descendants are listed with the descendants of Benjamin, though his relations to Benjamin are not stated.

(2) A Levite; ancestor to David's singer Asaph, and a descendant of the fifth generation from Gershom (1Ch 6:41).

(3) The father of Maaseiah, who was one of the captains of hundreds associated with Jehoiada the priest in making Joash king (2Ch 23:1).

(4) A resident of Bozkath, and father of Jedidah the mother of King Josiah (2Ki 22:1).

(5) A descendant of Judah through Perez. His great-great-grandson Maaseiah resided in Jerusalem after Nehemiah had rehabilitated the city (Ne 11:5).

(6) One of the men of Israel, not a priest or Levite, but "of the sons of Bani," who promised Ezra that he would part with his foreign wife (Ezr 10:29).

(7) The same man or another, in a different group of the sons of Bani (Ezr 10:39).

(8) One of the priests of the latest Bible times, mentioned with a partial genealogy (Ne 11:12; 1Ch 9:12).

Willis J. Beecher
