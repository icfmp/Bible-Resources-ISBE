# ALBEIT

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: ef584de25eebe60393d9c51297fff1bcd1bc5dc75ddb000f9acbffb743cecc92 -->

ol-be'-it (hina me; literally, "lest"): Occurs in a paraphrase rather than as a translation of a clause in Phm 1:19 the King James Version. The thought is: "although" or "albeit" (synonym of "although") "I might say," etc. This the Revised Version (British and American) translates with intense literalness: "that I say not".
