# ALLON-BACUTH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: b5c2eba0733ae8c844d5d7108b84437c08aae6b8292882e62e6fd9b17d9855f0 -->

al'-on-ba'-kuth ('allon bakhuth; the King James Version transliterates Allon-bachuth, al-on-bak'uth, "oak of weeping"): The burial place of Deborah, the nurse of Rebekah (Ge 35:8); it appears from the narrative that she made her home with Jacob, who had returned from Paddan-aram, and was sojourning at the time at Bethel, in the vicinity of which was the "oak of weeping," under which she was buried.
