# AGGABA

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: f35e56f67af8e20bad3a278034c6bb3183a7519978eed40c0a4c471ee007a74d -->

a-ga'-ba (Aggaba, and Agraba; the King James Version, Graba) = Hagabah (Ezr 2:45) and Hagaba (Ne 7:48): The descendants of Abraham (temple-servants) returned with Zerubbabel to Jerusalem (1 Esdras 5:29).

See also ACCABA.
