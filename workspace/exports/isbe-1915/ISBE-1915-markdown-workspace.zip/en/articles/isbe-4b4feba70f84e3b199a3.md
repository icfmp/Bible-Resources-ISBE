# ACIPHA

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 0982e8be97888dcbeddf663dbd4cf3f59941424bf7d540a1c7b3b684942aa827 -->

as'-i-fa. See ACHIPHA.
