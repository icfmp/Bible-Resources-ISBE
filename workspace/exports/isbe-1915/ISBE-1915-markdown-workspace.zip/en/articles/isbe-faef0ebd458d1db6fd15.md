# AKRABATTINE

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 666612dce042623838d54d15e0dff389f91c0585381e38d25348548e195d0779 -->

ak-ra-ba-ti'-ne (Akrabattine; the King James Version, Arabattine): A place in Idumaea where Judas Maccabee defeated the children of Esau (1 Macc 5:3).
