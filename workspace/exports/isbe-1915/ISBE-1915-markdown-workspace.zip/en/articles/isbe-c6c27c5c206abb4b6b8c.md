# ANAEL

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: eebcf7ac3249a1f8028a7a475b3e447ecb4d32d571efb7569eba259919c5a4b8 -->

an'-a-el (Anael): A brother of Tobit mentioned once only (/APC Tobit 1:21) as the father of Achiacharus, who was an official in Nineveh under Esar-haddon.
