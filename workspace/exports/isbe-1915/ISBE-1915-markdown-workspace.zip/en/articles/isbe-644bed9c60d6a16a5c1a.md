# ABYSSINIA

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 5e6c40de912de08d6cbb5712c8d45a1d9ab798ccc43efec3d53355f3932436f7 -->

ab-i-sin'-i-a. See ETHIOPIA.
