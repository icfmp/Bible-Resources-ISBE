# ADDAR

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 79818f806154bf19d37a1a9f96e30b9c464e22452248b1561480be80aa2ddb8e -->

ad'-ar ('addar, "glorious"): See ARD

(1) A grandson of Benjamin, sometimes counted as one of his sons (1Ch 8:3).

(2) A town on the southern border of Judah (Jos 15:3, the King James Version "Adar"). The same as Hazar-addar (Nu 34:4).
