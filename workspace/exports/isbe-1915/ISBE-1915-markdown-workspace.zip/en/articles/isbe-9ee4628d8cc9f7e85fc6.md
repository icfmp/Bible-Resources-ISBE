# ABIJAH

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: b2cd7f0e83553a59c75d47cd62743bc5592edebbdc81856da20f06737d9a0840 -->

a-bi'-ja ('abhiyah or 'abhiyahu (2Ch 13:20,21), "my father is Yahweh," or "Yahweh is father"): The name of six or more men and two women in the Old Testament.

(1) The seventh son of Becher the son of Benjamin (1Ch 7:8).

(2) The second son of the prophet Samuel (1Sa 8:2; 1Ch 6:28 (6:13)).

(3) The eighth among "the holy captains and captains of God" appointed by lot by David in connection with the priestly courses (1Ch 24:10). Compare "Zacharias of the course of Abijah" (Lu 1:5).

(4) A son of Jeroboam I of Israel (1Ki 14:1-18). The narrative describes his sickness and his mother's visit to the prophet Ahijah. He is spoken of as the one member of the house of Jeroboam in whom there was "found some good thing toward Yahweh." With his death the hope of the dynasty perished.

(5) The son and successor of Rehoboam king of Judah (1Ch 3:10; 2Ch 11:20-14:1). As to the variant name Abijam (1Ki 14:31; 15:1,7,8) see ABIJAM.

The statements concerning Abijah's mother afford great opportunity for a person who is interested in finding discrepancies in the Bible narrative. She is said to have been Maacah the daughter of Absalom (1Ki 15:2; 2Ch 11:20,21,22). As more than 50 years elapsed between the adolescence of Absalom and the accession of Rehoboam, the suggestion at once emerges that she may have been Absalom's daughter in the sense of being his granddaughter. But Maacha the daughter of Absalom was the mother of Asa, Abijam's son and successor (1Ki 15:10,13; 2Ch 15:16). Further we are explicitly told that Absalom had three sons and one daughter (2Sa 14:27). It is inferred that the three sons died young, inasmuch as Absalom before his death built him a monument because he had no son (2Sa 18:18). The daughter was distinguished for her beauty, but her name was Tamar, not Maacah. Finally, the narrative tells us that the name of Abijah's mother was "Micaiah the daughter of Uriel of Gibeah" (2Ch 13:2).

It is less difficult to combine all these statements into a consistent account than it would be to combine some pairs of them if taken by themselves. When all put together they make a luminous narrative, needing no help from conjectural theories of discrepant sources or textual errors. It is natural to understand that Tamar the daughter of Absalom married Uriel of Gibeah; that their daughter was Maacah, named for her great-grandmother (2Sa 3:3; 1Ch 3:2); that Micaiah is a variant of Maacah, as Abijah is of Abijam. Maacah married Rehoboam, the parties being second cousins on the father's side; if they had been first cousins perhaps they would not have married. Very likely Solomon, through the marriage, hoped to conciliate an influential party in Israel which still held the name of Absalom in esteem; perhaps also he hoped to supplement the moderate abilities of Rehoboam by the great abilities of his wife. She was a brilliant woman, and Rehoboam's favorite (2Ch 11:21). On Abijah's accession she held at court the influential position of king's mother; and she was so strong that she continued to hold it, when, after a brief reign, Abijah was succeeded by Asa; though it was a position from which Asa had the authority to depose her (1Ki 15:13; 2Ch 15:16).

The account in Chronicles deals mainly with a decisive victory which, it says, Abijah gained over northern Israel (2Ch 13), he having 400,000 men and Jeroboam 800,000, of whom 500,000 were slain. It is clear that these numbers are artificial, and were so intended, whatever may be the key to their meaning. Abijah's speech before the battle presents the same view of the religious situation which is presented in Kings and Amos and Hosea, though with fuller priestly details. The orthodoxy of Abijah on this one occasion is not in conflict with the representation in Kings that he followed mainly the evil ways of his father Rehoboam. In Chronicles coarse luxury and the multiplying of wives are attributed to both father and son.

(6) A priest of Nehemiah's time, who sealed the covenant (Ne 10:7). Conjecturally the same with the one mentioned in Ne 12:4,17.

(7) The wife of Judah's grandson Hezron, to whom was traced the origin of Tekoa (1Ch 2:24).

(8) The mother of King Hezekiah (2Ch 29:1), called Abi in 2 Ki. See ABI.

Willis J. Beecher
