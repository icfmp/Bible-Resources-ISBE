# AIR

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 2f6f7bb4c71c83890c4382fe3aab2d18493e7a0032a49fdd04c2d8b6bb27a2e5 -->

ar (aer): In the Old Testament "air" is used (with one exception) in the phrase "fowl" or "fowls (birds) of the air." The Hebrew word is usually rendered "heaven" or "heavens." According to ancient Hebrew cosmogony the sky was a solid dome (firmament) stretching over the earth as a covering. In the above phrase the air means the space between the earth and the firmament. In Job 41:16 "air" renders ruach, "breath," "wind," "spirit." The scales of the leviathan are so closely joined together that no air can penetrate. In the New Testament the phrase "birds (or fowls) of the air," occurs ten times. This simply reproduces the Hebraism noticed above. Apart from this expression "air" in the King James Version represents aer, which denotes the atmosphere which surrounds us. The expression "beating the air" (1Co 9:26) means to "deal blows that do not get home"--that miss the mark. In his conflict with the lower life represented by the body, Paul compares himself to a boxer who aims with unerring accuracy at his opponent. No stroke is lost. Paul also uses the phrase "speaking into the air" (1Co 14:9) in reference to the unintelligible utterances of those who "spake with tongues." In the expression, "prince of the powers of the air" (Eph 2:2 the King James Version) we find an echo of the current belief that the air was the dwelling place of spirits, especially of evil spirits.

Thomas Lewis
