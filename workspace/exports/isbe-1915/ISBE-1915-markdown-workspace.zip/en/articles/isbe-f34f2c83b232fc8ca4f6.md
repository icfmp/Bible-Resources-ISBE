# AGAR

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: ff3ce6c2f73e6e3f9b11aaced5393a1aedbf612e41c6e9bd4b60165c1143eafd -->

a'-gar (Agar). Found once in the Apocrypha in the Greek (Baruch 3:23) probably for the Old Testament Hagar, mother of Ishmael, whose children are mentioned with the merchants of Meran (Midian) and Teman. In 1Ch 5:10 the "Hagarites" the King James Version, are located East of Gilead, and In the days of Saul were at war with the tribe of Reuben. See also 1Ch 5:19,20 and 1Ch 27:31. In Ps 83:6 the name of the same people is Hagarenes.
