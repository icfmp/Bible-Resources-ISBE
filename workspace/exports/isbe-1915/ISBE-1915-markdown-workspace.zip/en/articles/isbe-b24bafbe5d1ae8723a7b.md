# ADIN

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 6c8fce109cf69e3a9504dcc40e802e819cd74aa771dbea83e8d50a60c3c5b7f7 -->

a'-din (`adhin, "adorned"): The name of a family, "the sons of Adin" (Ezr 2:15; 8:6; Ne 7:20; 10:16; 1 Esdras 5:14; 8:32), mentioned among the returning exiles. The list in Ezr 2 is placed in the midst of the narrative concerning Zerubbabel, but its title and Its contents show that it also includes the later Jewish immigrants into Palestine. The list in Ne 7 is a duplicate of that in Ezr, but with variations; most of the variations are naturally accounted for by supposing that one copy was made later than the other and was brought up to date. In Ezr and 1 Esdras the number of the sons of Adin is said to be 454; in Ne it is 655. The 50 males, led by Ebed the son of Jonathan, who came with Ezr, may or may not have been included in the numbers just mentioned. Among the names of those who sealed the covenant along with Ne are 44 that are placed under the caption "the chiefs of the people" (Ne 10:14-26), and nearly half of these are the family names of the list in Ezr 2 and Ne 7. It is natural to infer that in these cases a family sealed the covenant collectively through some representative. In that case the Adin here mentioned is the same that is mentioned in the other places. See also ADINU.

Willis J. Beecher
