# ACHBOR

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 39259fa3719a74912a294e27c42ef37775130e4afb8843b970191b9d2edc73f2 -->

ak'-bor (`akhbor, "mouse"):

(1) The father of Baal-hanan, who was the seventh of the eight kings who reigned in Edom before there were kings in Israel (Ge 36:38,39; 1Ch 1:49).

(2) The son of Micaiah (called in Chronicles Abdon the son of Micah) who went with Hilkiah the priest and other high officials, at the command of King Josiah, to consult Huldah the prophetess concerning the book that had been found (2Ki 22:12,14; 2Ch 34:20).

It may be presumed that this Achbor is also the man mentioned in Jer 26:22; 36:12, as the father of Elnathan, who went to Egypt for King Jehoiakim in order to procure the extradition of Uriah the prophet, and who protested against the burning of Baruch's roll.

Willis J. Beecher
