# AMOK

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 83ebe778cf6631f470d6747d029f6cae6594fda16ddbc97a26e9f6ebcefaeb74 -->

a'-mok (`amoq, "deep"): A chief priest who came to Jerusalem with Zerubbabel (Ne 12:7) and the forefather of Eber, who was priest in the days of Joiakim (Ne 12:20).
