# ALTOGETHER

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: a2f62be2a955a6bb7c6e2e4d60dda8853d42e202c6c115b3bcb4879f1f610552 -->

ol-too-geth'-er: Representing five Hebrew and three Greek originals, which variously signify

(1) "together"; i.e. all, e.g. `all men, high and low, weighed together in God's balance are lighter than vanity' (Ps 62:9); so also Ps 53:3; Jer 10:8.

(2) "all": so the Revised Version (British and American), Isa 10:8: "Are not my princes all of them kings?"

(3) "with one accord have broken the yoke"; so the Revised Version (British and American), Jer 5:5.

(4) "completely," "entirely," "fully": "so as not to destroy him altogether" (2Ch 12:12; compare Ge 18:21; Ex 11:1; Ps 39:5; Jer 30:11 the King James Version; compare the Revised Version (British and American)).

(5) "wholly": "altogether born in sins," Joh 9:34.

(6) In 1Co 5:10 the Revised Version (British and American) rendered "at all"; 1Co 9:10 "assuredly."

(7) A passage of classic difficulty to translators is Ac 26:29, where "altogether" in the Revised Version (British and American) is rendered "with much," Greek en megalo (en pollo). See ALMOST. Many of the instances where "altogether" occurs in the King James Version become "together" in the Revised Version (British and American). Used as an adjective in Ps 39:5 ("altogether vanity").

Dwight M. Pratt
