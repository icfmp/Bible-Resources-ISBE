# ABYSS

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: eb337cd33e86d8a40effe236671988e97f087e4744446547fb993c5ec6a3f1c1 -->

a-bis', (he abussos): In classical Greek the word is always an adjective, and is used

(1) literally, "very deep," "bottomless";

(2) figuratively, "unfathomable," "boundless." "Abyss" does not occur in the King James Version but the Revised Version (British and American) so transliterates abussos in each case. The the King James Version renders the Greek by "the deep" in two passages (Lu 8:31; Ro 10:7). In Revelation the King James Version renders by "the bottomless pit" (Re 9:1,2,11; 11:7; 17:8; 20:1,3). In the Septuagint abussos is the rendering of the Hebrew word tehom. According to primitive Semitic cosmogony the earth was supposed to rest on a vast body of water which was the source of all springs of water and rivers (Ge 1:2; De 8:7; Ps 24:2; 136:6). This subterranean ocean is sometimes described as "the water under the earth" (Ex 20:4; De 5:8). According to Job 41:32 tehom is the home of the leviathan in which he plows his hoary path of foam. The Septuagint never uses abussos as a rendering of sheol (= Sheol = Hades) and probably tehom never meant the "abode of the dead" which was the ordinary meaning of Sheol. In Ps 71:20 tehom is used figuratively, and denotes "many and sore troubles" through which the psalmist has passed (compare Jon 2:5). But in the New Testament the word abussos means the "abode of demons." In Lu 8:31 the King James Version renders "into the deep" (Weymouth and The Twentieth Century New Testament = "into the bottomless pit"). The demons do not wish to be sent to their place of punishment before their destined time. Mark simply says "out of the country" (Lu 5:10). In Ro 10:7 the word is equivalent to Hades, the abode of the dead. In Revelation (where the King James Version renders invariably "the bottomless pit") abussos denotes the abode of evil spirits, but not the place of final punishment; it is therefore to be distinguished from the "lake of fire and brimstone" where the beast and the false prophet are, and into which the Devil is to be finally cast (Re 19:20; 20:10).

See also ASTRONOMY, sec. III, 7.

Thomas Lewis
