# ABIDE

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 146631b518623cacd799c02659d4aff971c01ae2d54b2098540f800a53a7bd90 -->

a-bid': Old English word signifying progressively to "await," "remain," "lodge," "sojourn," "dwell," "continue," "endure"; represented richly in Old Testament (King James Version) by 12 Hebrew and in New Testament by as many Greek words. In the Revised Version (British and American) displaced often by words meaning "to sojourn," "dwell," "encamp." The Hebrew and Greek originals in most frequent use are yashabh, "to dwell"; meno, "to remain." "A. [sit or tarry] ye here" (Ge 22:5); "The earth a. [continueth] forever" (Ec 1:4); "Who can a. [bear or endure] the day?" (Mal 3:2); "Afflictions a. [await] me" (Ac 20:23). The past tense abode, in frequent use, has the same meaning. "His bow a. [remained] in strength" (Ge 49:24); "There he a." (dwelt) (Joh 10:40).

Abode, as a noun (Gr μονή, monē) twice in New Testament: "make our a. with him" (Joh 14:23); "mansions," the Revised Version, margin "abiding-places" (Joh 14:2). The soul of the true disciple and heaven are dwelling-places of the Father, Son and Holy Spirit.

Dwight M. Pratt
