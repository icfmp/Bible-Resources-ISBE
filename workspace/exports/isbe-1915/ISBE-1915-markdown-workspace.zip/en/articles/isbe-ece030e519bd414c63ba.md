# AHIMAAZ

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 74eadc6eeb04e5dd556037792f62c9f74d80eb4c94b055de8afecf762fa47c14 -->

a-hi-ma'-az, a-him'-a-az ('achima`ats, perhaps "my brother is rage," or "brother of rage"):

(1) Father of Ahinoam the wife of King Saul (1Sa 14:50).

(2) The son of Zadok the high priest (1Ch 6:8,9,53). With his father he remained loyal to David in the rebellions both of Absalom and of Adonijah. With Jonathan the son of Abiathar he carried information to Dared when he fled from Absalom (2Sa 15:27,36; 17:17,20). At his own urgent request he carried tidings to David after the death of Absalom (2Sa 18:19 ff). He told the king of the victory, and also, through his reluctance to speak, informed him of Absalom's death. By his reluctance and his sympathy he softened a little the message, which the Cushite presently repeated more harshly.

That Ahimaaz did not succeed his father as high priest has been inferred from the fact that in the Solomon list of heads of departments (1Ki 4:2) Azariah the son of Zadok is mentioned as priest. It is assumed that this Azariah is the one who appears in the genealogy as the son of Ahimaaz, and that for some reason Ahimaaz was left out of the succession. These inferences are not Justified by the record, though possibly the record does not absolutely disprove them. As the list stands it makes Zadok and Abiathar the high priests. Azariah and Zabud, the son of Nathan (1Ki 4:2,5), are spoken of as holding priestly offices of a different kind. Ahimaaz may have died early, or may have followed some other career, but the simple fact is that we do not know.

(3) Ahimaaz, in Naphtali, was one of Solomon's twelve commissary officers (1Ki 4:15), who married Basemath the daughter of Solomon. It is not impossible that he was Ahimaaz the son of Zadok, though there is no proof to that effect.

Willis J. Beecher
