# AMI

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 03586e62f54b6d2254847524641ff890ceacf904e41e8eae98b94b48932f4095 -->

a'-mi, a'-me ('ami): Ancestor of a family among "Solomon's servants" in the Return (Ezr 2:57); the same as Amon in Ne 7:59.
