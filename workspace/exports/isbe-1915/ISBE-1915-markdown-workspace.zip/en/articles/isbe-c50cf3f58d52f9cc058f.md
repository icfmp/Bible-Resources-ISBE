# AHIMAN

<!-- Historical English source, not a translation. -->
<!-- Canonical SWORD key and identifiers are in the paired JSON map. -->
<!-- Source article SHA-256: 4ed6c0b133acf7d2cfe2c6a338570640c392a0963233739c02f1731280a7ed4c -->

a-hi'-man ('achiman, perhaps, "brother of fortune," or, "my brother is fortune"):

(1) One of the names given as those of the three "children of the Anak" (Nu 13:22; Jos 15:14; Nu 13:28; 2Sa 21:16,18), or the three "sons of the Anak" (Jos 15:14; Jud 1:20). The three names (Ahiman, Sheshai, Talmai) also occur together in Jud 1:10. The word Anak in the Hebrew Bible has the definite article except in Nu 13:33 and De 9:2. Its use is that of a common noun denoting a certain type of man, rather than as the proper name of a person or a clan, though this need not prevent our thinking of the Anakim as a clan or group of clans, who regarded Arba as their founder. The question is raised whether Ahiman and Sheshai and Talmai are to be thought of as persons or as clans. The most natural understanding of the Bible statements is certainly to the effect that they were personal leaders among the Anakim of Kiriath-arba (Hebron). They were smitten and dispossessed by the tribe of Judah, with Caleb for leader.

(2) A Levite, one of the gatekeepers of the latest Bible times (1Ch 9:17). He is associated with Akkub and Talmon and their brethren: compare Ne 11:19.

Willis J. Beecher
